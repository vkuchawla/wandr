import { useState } from "react";
import { T, GLOBAL_CSS, NAV_H, VIBES, DNA_TYPES } from "./constants.jsx";
function ProfileScreen({ profile, onSaveProfile, isOnboarding = false, supabase }) {
  const [step, setStep]       = useState(profile ? "done" : "name");
  const [name, setName]       = useState(profile?.name||"");
  const [answers, setAnswers] = useState(profile?.answers||{});
  const [qIdx, setQIdx]       = useState(0);

  const questions = isOnboarding ? ONBOARDING_QUESTIONS : QUIZ_QUESTIONS;
  const [finalAnswers, setFinalAnswers] = useState(null);

  const answer = (qId, val) => {
    const next = {...answers, [qId]:val};
    setAnswers(next);
    if (qIdx < questions.length-1) setQIdx(q=>q+1);
    else {
      setFinalAnswers(next);
      if (isOnboarding) {
        setStep("reveal");
      } else {
        onSaveProfile({name, answers:next});
        setStep("done");
      }
    }
  };

  const TRAVEL_DNAS = {
    slow_savourer: {
      label: "The Slow Savourer",
      emoji: "☕",
      color: "#a0522d",
      bg: "linear-gradient(135deg,#2d1a0e,#4a2810)",
      description: "You believe the best trips aren't measured in miles but in moments. A perfect morning is a two-hour breakfast watching the city wake up. You're not here to tick boxes — you're here to actually feel somewhere.",
      traits: ["Late riser", "Unhurried", "Atmosphere seeker", "Moment collector"],
    },
    hyper_planner: {
      label: "The Hyper-Planner",
      emoji: "📋",
      color: "#1a3a6b",
      bg: "linear-gradient(135deg,#0e1a2d,#1a2d4a)",
      description: "You've read every review, mapped every route, and built a color-coded spreadsheet for your last three trips. Spontaneity makes you nervous — and that's okay, because your trips are genuinely incredible.",
      traits: ["Meticulous", "Research-driven", "Maximizer", "Detail obsessed"],
    },
    food_explorer: {
      label: "The Food-First Explorer",
      emoji: "🍷",
      color: "#8b1a2f",
      bg: "linear-gradient(135deg,#2d0e1a,#4a1a28)",
      description: "Every trip you've ever taken has been secretly organized around where you'll eat. You've waited two hours for a reservation, eaten at a market stall at midnight, and you regret nothing. Food is your love language.",
      traits: ["Culinary obsessed", "Reservation hunter", "Market wanderer", "Never skips dessert"],
    },
    off_path: {
      label: "The Off-Path Wanderer",
      emoji: "🔮",
      color: "#5a2d82",
      bg: "linear-gradient(135deg,#1a0e2d,#2d1a4a)",
      description: "Tourist traps make you physically cringe. You'd rather spend an afternoon in a neighborhood nobody's heard of than see one more famous landmark. Your best travel stories start with 'I just kind of wandered in...'",
      traits: ["Crowd avoider", "Hidden gem hunter", "Local seeker", "Anti-tourist"],
    },
    free_spirit: {
      label: "The Free Spirit",
      emoji: "🎲",
      color: "#255c3f",
      bg: "linear-gradient(135deg,#0e2d1a,#1a4a2d)",
      description: "You booked this trip three days ago and you still don't have a hotel for Tuesday. That's fine — something always works out. Your best travel memories were completely unplanned, and you wouldn't have it any other way.",
      traits: ["Spontaneous", "Adaptable", "Serendipity believer", "No itinerary needed"],
    },
    balanced: {
      label: "The Balanced Traveller",
      emoji: "⚖",
      color: "#4a3a10",
      bg: "linear-gradient(135deg,#1a1a0e,#2d2a1a)",
      description: "You've figured out what most travellers never do: how to have a plan without being enslaved by it. You do your research, leave room for surprises, and somehow always manage to see everything worth seeing without feeling exhausted.",
      traits: ["Thoughtful", "Flexible", "Experienced", "Best of both worlds"],
    },
  };

  const getDNA = (a) => {
    if (!a) return TRAVEL_DNAS.balanced;
    if (a.pace==="slow" && (a.sleep==="late" || a.vibe==="relax")) return TRAVEL_DNAS.slow_savourer;
    if (a.pace==="fast" && a.style==="planner") return TRAVEL_DNAS.hyper_planner;
    if (a.food==="everything") return TRAVEL_DNAS.food_explorer;
    if (a.crowd==="hate" && a.vibe==="immerse") return TRAVEL_DNAS.off_path;
    if (a.style==="spontaneous") return TRAVEL_DNAS.free_spirit;
    return TRAVEL_DNAS.balanced;
  };

  const travelStyle = () => {
    if (!profile?.answers && !answers) return null;
    return getDNA(profile?.answers || answers)?.label;
  };

  const dna = getDNA(finalAnswers || answers);

  if (step === "reveal") return (
    <div style={{minHeight:"100vh",background:dna.bg,fontFamily:"'DM Sans',sans-serif",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"48px 28px",position:"relative",overflow:"hidden"}}>
      <style>{GLOBAL_CSS}</style>
      {/* Background decoration */}
      <div style={{position:"absolute",top:-60,right:-60,fontSize:200,opacity:0.04,fontFamily:"serif"}}>{dna.emoji}</div>
      <div style={{position:"absolute",bottom:-40,left:-40,fontSize:160,opacity:0.03,fontFamily:"serif"}}>{dna.emoji}</div>

      {/* Content */}
      <div style={{position:"relative",zIndex:1,width:"100%",maxWidth:360,textAlign:"center",animation:"fadeUp 0.6s ease"}}>
        {/* Emoji */}
        <div style={{fontSize:64,marginBottom:20,animation:"pop 0.5s ease 0.2s both"}}>{dna.emoji}</div>

        {/* Label */}
        <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.22em",textTransform:"uppercase",color:"rgba(255,255,255,0.4)",marginBottom:10}}>Your travel DNA</div>
        <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:38,fontWeight:900,color:"white",lineHeight:1.1,marginBottom:20,animation:"fadeUp 0.5s ease 0.1s both"}}>
          {dna.label}
        </h1>

        {/* Description */}
        <p style={{fontSize:15,color:"rgba(255,255,255,0.7)",lineHeight:1.7,marginBottom:28,animation:"fadeUp 0.5s ease 0.2s both"}}>
          {dna.description}
        </p>

        {/* Trait tags */}
        <div style={{display:"flex",flexWrap:"wrap",gap:8,justifyContent:"center",marginBottom:40,animation:"fadeUp 0.5s ease 0.3s both"}}>
          {dna.traits.map(trait=>(
            <span key={trait} style={{padding:"6px 14px",borderRadius:20,background:"rgba(255,255,255,0.1)",border:"1px solid rgba(255,255,255,0.15)",fontSize:12,fontWeight:600,color:"rgba(255,255,255,0.8)"}}>
              {trait}
            </span>
          ))}
        </div>

        {/* Name personalization */}
        {name && (
          <div style={{fontSize:13,color:"rgba(255,255,255,0.4)",marginBottom:24,fontStyle:"italic"}}>
            Welcome to Wandr, {name}.
          </div>
        )}

        {/* CTA */}
        <button onClick={()=>{ onSaveProfile({name, answers: finalAnswers || answers}); setStep("done"); }}
          style={{width:"100%",padding:"18px 0",borderRadius:18,background:"white",border:"none",color:dna.color||T.ink,fontSize:16,fontWeight:800,cursor:"pointer",boxShadow:"0 8px 32px rgba(0,0,0,0.2)",animation:"fadeUp 0.5s ease 0.4s both",letterSpacing:"0.02em"}}>
          Start planning ✦
        </button>
      </div>
    </div>
  );

  if (step === "name") return (
    <div style={{minHeight:"100vh",background:T.cream,fontFamily:"'DM Sans',sans-serif",display:"flex",flexDirection:"column",padding:`56px 24px ${NAV_H+28}px`}}>
      <style>{GLOBAL_CSS}</style>
      <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.22em",textTransform:"uppercase",color:T.gold,marginBottom:16}}>✦ WANDR</div>
      <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:34,fontWeight:700,color:T.ink,lineHeight:1.2,marginBottom:8}}>{isOnboarding ? "Welcome to Wandr." : "Let's get to know you."}</h1>
      <p style={{fontSize:14,color:T.inkFaint,lineHeight:1.7,marginBottom:32}}>{isOnboarding ? "Answer a few quick questions and we'll personalise every itinerary to your travel style." : "We'll use your travel style to personalise every itinerary."}</p>

      <div style={{marginBottom:12,fontSize:13,fontWeight:600,color:T.inkLight}}>What should we call you?</div>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name…"
        style={{width:"100%",padding:"15px 18px",borderRadius:14,border:`1.5px solid ${T.dust}`,background:T.white,color:T.ink,fontSize:16,fontWeight:600,outline:"none",marginBottom:20}}/>
      <button onClick={()=>name.trim()&&setStep("quiz")} disabled={!name.trim()}
        style={{width:"100%",padding:16,borderRadius:16,background:name.trim()?T.ink:T.dust,border:"none",color:name.trim()?T.white:T.inkFaint,fontSize:15,fontWeight:800,cursor:name.trim()?"pointer":"default",marginBottom:12}}>
        Start the quiz →
      </button>
      {isOnboarding && (
        <button onClick={()=>onSaveProfile({name:name.trim()||"Traveller", answers:{}})}
          style={{width:"100%",padding:13,borderRadius:16,background:"none",border:`1.5px solid ${T.dust}`,color:T.inkFaint,fontSize:14,cursor:"pointer"}}>
          Skip for now
        </button>
      )}
    </div>
  );

  if (step === "quiz") {
    const q = questions[qIdx];
    const selected = answers[q.id];

    // Background colors per question for visual variety
    const qBgs = ["#f8f4ed","#f0ece0","#f4f0e8","#f8f4ed","#f0ece0","#f4f0e8","#f8f4ed","#f0ece0"];
    const bg = qBgs[qIdx % qBgs.length];

    return (
      <div style={{minHeight:"100vh",background:bg,fontFamily:"'DM Sans',sans-serif",display:"flex",flexDirection:"column"}}>
        <style>{GLOBAL_CSS}</style>

        {/* Top bar */}
        <div style={{padding:"52px 24px 0",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <button onClick={()=>qIdx>0?setQIdx(i=>i-1):setStep("name")}
            style={{background:"none",border:"none",color:T.inkFaint,fontSize:22,cursor:"pointer",padding:0,lineHeight:1}}>
            ←
          </button>
          {/* Progress dots */}
          <div style={{display:"flex",gap:6,alignItems:"center"}}>
            {questions.map((_,i)=>(
              <div key={i} style={{width:i===qIdx?20:6,height:6,borderRadius:3,background:i<qIdx?T.accent:i===qIdx?T.ink:T.dust,transition:"all 0.3s ease"}}/>
            ))}
          </div>
          <button onClick={()=>{
            if (qIdx < questions.length-1) setQIdx(i=>i+1);
            else { setFinalAnswers(answers); setStep(isOnboarding ? "reveal" : "done"); }
          }} style={{background:"none",border:"none",color:T.inkFaint,fontSize:13,fontWeight:600,cursor:"pointer",padding:0}}>
            Skip
          </button>
        </div>

        {/* Question */}
        <div style={{padding:"32px 24px 20px",flex:1,display:"flex",flexDirection:"column"}}>
          <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.18em",textTransform:"uppercase",color:T.gold,marginBottom:12}}>
            Question {qIdx+1}
          </div>
          <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:32,fontWeight:700,color:T.ink,lineHeight:1.2,marginBottom:32,animation:"fadeUp 0.35s ease"}}>
            {q.question}
          </h2>

          {/* Visual option cards */}
          <div style={{display:"flex",flexDirection:"column",gap:12,flex:1}}>
            {q.options.map((opt, i) => {
              const isSelected = selected === opt.v;
              return (
                <button key={opt.v} onClick={()=>answer(q.id, opt.v)}
                  style={{
                    padding:"20px 22px",
                    borderRadius:20,
                    border:`2.5px solid ${isSelected?T.accent:"rgba(28,22,18,0.08)"}`,
                    background:isSelected?T.ink:T.white,
                    cursor:"pointer",
                    textAlign:"left",
                    display:"flex",
                    alignItems:"center",
                    gap:16,
                    boxShadow:isSelected?"0 8px 24px rgba(28,22,18,0.15)":"0 2px 8px rgba(28,22,18,0.04)",
                    transition:"all 0.2s ease",
                    animation:`fadeUp 0.3s ease ${i*0.06}s both`,
                    transform:isSelected?"scale(1.01)":"scale(1)"
                  }}>
                  {/* Emoji bubble */}
                  <div style={{
                    width:52,
                    height:52,
                    borderRadius:16,
                    background:isSelected?"rgba(255,255,255,0.12)":"#f4ede4",
                    display:"flex",
                    alignItems:"center",
                    justifyContent:"center",
                    fontSize:26,
                    flexShrink:0,
                    transition:"background 0.2s"
                  }}>
                    {opt.e}
                  </div>
                  {/* Text */}
                  <div style={{flex:1}}>
                    <div style={{fontSize:16,fontWeight:700,color:isSelected?T.white:T.ink,lineHeight:1.2,marginBottom:2}}>
                      {opt.l}
                    </div>
                    {opt.sub && <div style={{fontSize:12,color:isSelected?"rgba(255,255,255,0.5)":T.inkFaint}}>{opt.sub}</div>}
                  </div>
                  {/* Check */}
                  <div style={{
                    width:24,
                    height:24,
                    borderRadius:"50%",
                    background:isSelected?T.accent:"transparent",
                    border:`2px solid ${isSelected?T.accent:T.dust}`,
                    display:"flex",
                    alignItems:"center",
                    justifyContent:"center",
                    flexShrink:0,
                    transition:"all 0.2s"
                  }}>
                    {isSelected && <span style={{color:"white",fontSize:13,fontWeight:700}}>✓</span>}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Done state
  const style = travelStyle();
  return (
    <div style={{minHeight:"100vh",background:T.cream,fontFamily:"'DM Sans',sans-serif",padding:`56px 24px ${NAV_H+28}px`}}>
      <style>{GLOBAL_CSS}</style>
      <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.22em",textTransform:"uppercase",color:T.gold,marginBottom:20}}>✦ YOUR PROFILE</div>
      {/* Identity card */}
      <div style={{background:`linear-gradient(135deg,${T.ink},#2d1f10)`,borderRadius:24,padding:"28px 24px",marginBottom:24,position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:-20,right:-20,fontSize:80,opacity:0.06}}>✦</div>
        <div style={{fontSize:13,color:"rgba(255,255,255,0.4)",marginBottom:6}}>traveller</div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:28,fontWeight:700,color:T.white,marginBottom:4}}>{profile?.name||name}</div>
        {style&&<div style={{display:"inline-block",background:T.accent,borderRadius:20,padding:"4px 14px",fontSize:12,fontWeight:700,color:T.white,marginTop:8}}>{style}</div>}
      </div>
      {/* Answers summary */}
      <div style={{background:T.white,borderRadius:18,padding:"20px",marginBottom:20,border:`1px solid ${T.dust}`}}>
        <div style={{fontSize:12,fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:T.inkFaint,marginBottom:14}}>Your travel DNA</div>
        {QUIZ_QUESTIONS.map(q=>{
          const a = (profile?.answers||answers)[q.id];
          const opt = q.options.find(o=>o.v===a);
          return opt ? (
            <div key={q.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${T.dust}`}}>
              <span style={{fontSize:13,color:T.inkLight}}>{q.question}</span>
              <span style={{fontSize:13,fontWeight:700,color:T.ink}}>{opt.e} {opt.l}</span>
            </div>
          ) : null;
        })}
      </div>
      {isOnboarding ? (
        <button onClick={()=>onSaveProfile({name, answers})}
          style={{width:"100%",padding:16,borderRadius:16,background:T.ink,border:"none",color:T.white,fontSize:15,fontWeight:800,cursor:"pointer",boxShadow:"0 6px 20px rgba(28,22,18,0.15)"}}>
          Start planning ✦
        </button>
      ) : (
        <button onClick={()=>setStep("name")}
          style={{width:"100%",padding:14,borderRadius:14,background:"none",border:`1.5px solid ${T.dust}`,color:T.inkLight,fontSize:14,fontWeight:600,cursor:"pointer"}}>
          Retake the quiz
        </button>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// EXPLORE SCREEN
// ─────────────────────────────────────────────
export { ProfileScreen };