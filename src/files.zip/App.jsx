import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";
import { T, GLOBAL_CSS, NAV_H } from "./constants.jsx";
import { NavBar } from "./NavBar.jsx";
import { HomeScreen } from "./HomeScreen.jsx";
import { ProfileScreen } from "./ProfileScreen.jsx";
import { ExploreScreen } from "./ExploreScreen.jsx";
import { MoodBoard } from "./MoodBoard.jsx";
import { ItineraryView } from "./ItineraryView.jsx";
import { CityPage } from "./CityPage.jsx";
import { SavedTripsScreen } from "./SavedTripsScreen.jsx";
import { SocialScreen } from "./Social.jsx";
import { AuthGateModal, AuthScreen } from "./Auth.jsx";

export default function App() {
  const [screen, setScreen]         = useState("loading");
  const [city, setCity]             = useState("");
  const [dates, setDates]           = useState("");
  const [moodContext, setMoodContext] = useState("");
  const [savedTrips, setSavedTrips] = useState(() => {
    try { return JSON.parse(localStorage.getItem("wandr_trips") || "[]"); } catch(e) { return []; }
  });

  // Persist trips to localStorage whenever they change
  useEffect(() => {
    try { localStorage.setItem("wandr_trips", JSON.stringify(savedTrips)); } catch(e) {}
  }, [savedTrips]);
  const [profile, setProfile]       = useState(null);
  const [openTrip, setOpenTrip]     = useState(null);
  const [user, setUser]             = useState(null);
  const [authGate, setAuthGate]     = useState(null); // null | "save" | "social"

  // Auth state listener
  useEffect(() => {
    const timeout = setTimeout(() => {
      if (screen === "loading") setScreen("home");
    }, 3000);

    supabase.auth.getSession().then(({ data: { session } }) => {
      clearTimeout(timeout);
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id);
        loadTrips(session.user.id);
      } else {
        setScreen(prev => prev === "loading" ? "home" : prev);
      }
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id);
        loadTrips(session.user.id);
      } else {
        // Don't redirect — let them stay where they are
      }
    });
    return () => { subscription.unsubscribe(); clearTimeout(timeout); };
  }, []);

  const loadProfile = async (userId) => {
    const { data } = await supabase.from("profiles").select("*").eq("id", userId).single();
    if (data) {
      setProfile({ name: data.name, answers: data.answers, travelDna: data.travel_dna });
      // Only navigate to home if on a loading/auth screen
      setScreen(prev => ["loading","auth","onboarding"].includes(prev) ? "home" : prev);
    } else {
      setScreen("onboarding");
    }
  };

  const loadTrips = async (userId) => {
    const { data } = await supabase.from("trips").select("*").eq("user_id", userId).order("saved_at", { ascending: false });
    if (data) setSavedTrips(data.map(t => ({ ...t, days: t.days, moodContext: t.mood_context })));
  };

  const handleSaveProfile = async (p) => {
    setProfile(p);
    if (user) {
      await supabase.from("profiles").upsert({
        id: user.id,
        name: p.name,
        answers: p.answers,
        travel_dna: p.travelDna || null
      });
    }
    setScreen("home");
  };

  const handleSaveTrip = async (trip) => {
    if (!user) { setAuthGate("save"); return; }
    setSavedTrips(prev => [trip, ...prev.filter(t => !(t.city === trip.city && t.dates === trip.dates))]);
    await supabase.from("trips").upsert({
      user_id: user.id,
      city: trip.city,
      dates: trip.dates,
      mood_context: trip.moodContext,
      days: trip.days,
      emoji: trip.emoji || "✦",
      saved_at: new Date().toISOString()
    });
  };

  const handleStart = (c, d) => { setCity(c); setDates(d); setScreen("city"); };
  const handleBuild = (ctx) => { setMoodContext(ctx); setScreen("itinerary"); };
  const handleOpenTrip = (trip) => {
    if (!trip) { setScreen("saved"); return; }
    setOpenTrip(trip);
    setScreen("trip-detail");
  };

  if (screen === "loading") return (
    <div style={{width:"100%",minHeight:"100vh",background:T.ink,display:"flex",alignItems:"center",justifyContent:"center"}}>
      <div style={{fontFamily:"'Playfair Display',serif",fontSize:48,color:T.white,animation:"pulse 1.5s ease infinite"}}>✦</div>
    </div>
  );

  return (
    <div style={{width:"100%",minHeight:"100vh",background:"#e8e0d0",display:"flex",justifyContent:"center"}}>
      <div style={{width:"100%",maxWidth:480,minHeight:"100vh",background:T.cream,position:"relative",boxShadow:"0 0 80px rgba(28,22,18,0.15)"}}>
        {screen==="auth"        && <AuthScreen supabase={supabase} onSkip={()=>setScreen("onboarding")}/>}
        {screen==="onboarding"  && <ProfileScreen profile={null} onSaveProfile={handleSaveProfile} isOnboarding={true} supabase={supabase}/>}
        {screen==="home"        && <HomeScreen onStart={handleStart} savedTrips={savedTrips} profile={profile} onOpenTrip={handleOpenTrip}/>}
        {screen==="profile"     && <ProfileScreen profile={profile} onSaveProfile={handleSaveProfile} supabase={supabase}/>}
        {screen==="explore"     && <ExploreScreen onSelectCity={(c)=>{setCity(c);setScreen("city");}}/>}
        {screen==="social" && !user && <AuthGateModal supabase={supabase} reason="social" onClose={()=>setScreen("home")}/>}
        {screen==="social" && user  && <SocialScreen supabase={supabase} user={user} onRemix={(trip)=>{ setCity(trip.city); setDates(trip.dates||""); setMoodContext(trip.mood_context||""); setScreen("mood"); }}/>}
        {screen==="city" && <CityPage city={city} dates={dates} supabase={supabase} user={user} onPlan={()=>setScreen("mood")} onRemix={(trip)=>{ setMoodContext(trip.mood_context||""); setScreen("mood"); }} onBack={()=>setScreen("home")}/>}
        {screen==="mood"        && <MoodBoard city={city} dates={dates} onBuild={handleBuild} onBack={()=>setScreen("city")} profile={profile} remixContext={moodContext}/>}
        {screen==="itinerary"   && <ItineraryView city={city} dates={dates} moodContext={moodContext} profile={profile} onBack={()=>setScreen("mood")} onSave={handleSaveTrip}/>}
        {screen==="saved"       && <SavedTripsScreen savedTrips={savedTrips} onOpenTrip={handleOpenTrip} onPlanNew={()=>setScreen("home")}/>}
        {screen==="trip-detail" && openTrip && (
          <ItineraryView city={openTrip.city} dates={openTrip.dates} moodContext={openTrip.moodContext||openTrip.mood_context||""} preloadedDays={openTrip.days||[]} onBack={()=>setScreen("saved")} onSave={()=>{}}/>
        )}
        <NavBar screen={screen} setScreen={setScreen}/>
        {authGate && <AuthGateModal supabase={supabase} reason={authGate} onClose={()=>setAuthGate(null)}/>}
      </div>
    </div>
  );
}
