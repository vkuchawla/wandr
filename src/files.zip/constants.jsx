import { useState, useEffect, useRef } from "react";
import { createClient } from "@supabase/supabase-js";

// ─────────────────────────────────────────────
// SUPABASE
// ─────────────────────────────────────────────
const SUPABASE_URL = "https://ejutttjjptmkhyqxoytl.supabase.co";
const SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVqdXR0dGpqcHRta2h5cXhveXRsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM0NTA4MzgsImV4cCI6MjA4OTAyNjgzOH0.kac5jh8nTs_IoruG2GlNkGWpRWZsyw_XcUj0hQmcdZ4";
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON);

// ─────────────────────────────────────────────
// DESIGN TOKENS
// ─────────────────────────────────────────────
const T = {
  cream:    "#f8f4ed",
  paper:    "#f2ece0",
  ink:      "#1c1612",
  inkLight: "#5c4f3d",
  inkFaint: "#b0a090",
  accent:   "#c84b2f",
  gold:     "#c49a3c",
  sage:     "#4a7c59",
  dust:     "#e8dfd0",
  white:    "#ffffff",
};

// Nav bar height constant — used to ensure content isn't hidden behind nav
const NAV_H = 72;

const FONTS = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400&display=swap');
`;

const GLOBAL_CSS = `
  ${FONTS}
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html { font-size: 16px; }
  body { background: #e8e0d0; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
  ::-webkit-scrollbar { display: none; }
  input, button, select, textarea { font-family: 'DM Sans', sans-serif; font-size: 1rem; }
  @keyframes fadeUp   { from { opacity:0; transform:translateY(14px) } to { opacity:1; transform:translateY(0) } }
  @keyframes fadeIn   { from { opacity:0 } to { opacity:1 } }
  @keyframes pop      { 0%{transform:scale(1)} 40%{transform:scale(1.14)} 100%{transform:scale(1)} }
  @keyframes pulse    { 0%,100%{opacity:0.4} 50%{opacity:1} }
  @keyframes shimmer  { 0%{background-position:200% center} 100%{background-position:-200% center} }
  @keyframes slideUp  { from{transform:translateY(100%);opacity:0} to{transform:translateY(0);opacity:1} }
  @keyframes spin     { to { transform: rotate(360deg) } }
  @keyframes marquee1 { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
  @keyframes marquee2 { 0% { transform: translateX(-50%); } 100% { transform: translateX(0); } }
`;

// ─────────────────────────────────────────────
// DATA
// ─────────────────────────────────────────────
const VIBES = [
  { id:"slow-morning",    label:"Slow Morning",     emoji:"☕", color:"#a0522d", bg:"#fdf0e8" },
  { id:"chill-afternoon", label:"Chill Afternoon",  emoji:"🌤", color:"#1e6b8a", bg:"#eaf4fb" },
  { id:"golden-hour",     label:"Golden Hour",      emoji:"🌅", color:"#b06000", bg:"#fff5e0" },
  { id:"spa-day",         label:"Spa & Wellness",   emoji:"🧘", color:"#4a7c59", bg:"#eaf6f0" },
  { id:"street-food",     label:"Street Food",      emoji:"🌮", color:"#b5600a", bg:"#fef5e7" },
  { id:"splurge-dinner",  label:"Splurge Dinner",   emoji:"🍷", color:"#8b1a2f", bg:"#fdf0f2" },
  { id:"nightlife",       label:"Nightlife",        emoji:"🌙", color:"#2d2060", bg:"#f0edf8" },
  { id:"coffee-crawl",    label:"Coffee Crawl",     emoji:"☕", color:"#5c3d1e", bg:"#fdf5ed" },
  { id:"brunch",          label:"Brunch Vibes",     emoji:"🥂", color:"#8b4513", bg:"#fef8f0" },
  { id:"cultural",        label:"Cultural",         emoji:"🏛",  color:"#4a3a10", bg:"#faf5e4" },
  { id:"adventurous",     label:"Adventurous",      emoji:"⚡", color:"#9b2020", bg:"#fdecea" },
  { id:"local-weird",     label:"Local & Weird",    emoji:"🔮", color:"#5a2d82", bg:"#f4eefa" },
  { id:"day-trip",        label:"Day Trip",         emoji:"🚗", color:"#255c3f", bg:"#eaf6f0" },
  { id:"nature",          label:"Nature & Parks",   emoji:"🌿", color:"#2d5a1b", bg:"#edf7e8" },
  { id:"shopping",        label:"Shopping",         emoji:"🛍",  color:"#8b1a6b", bg:"#fdf0fa" },
  { id:"sports",          label:"Sports",           emoji:"🏟",  color:"#1a5c30", bg:"#e8f8ef" },
  { id:"art",             label:"Art & Design",     emoji:"🎨", color:"#1a3a6b", bg:"#eaf0fb" },
  { id:"music",           label:"Live Music",       emoji:"🎵", color:"#5a1a6b", bg:"#f4eefa" },
];

const VIBE_CATEGORIES = [
  { label:"Pace",         ids:["slow-morning","chill-afternoon","golden-hour","spa-day"] },
  { label:"Food & Drink", ids:["street-food","splurge-dinner","coffee-crawl","brunch","nightlife"] },
  { label:"Experience",   ids:["cultural","adventurous","local-weird","day-trip","nature","art","music"] },
  { label:"Shopping & Events", ids:["shopping","sports"] },
];

// Shown during onboarding (quick)
const ONBOARDING_QUESTIONS = [
  {
    id:"pace", question:"Your ideal travel pace?",
    options:[{v:"slow",l:"Slow & savour",e:"🧘"},{v:"medium",l:"Balanced mix",e:"⚖"},{v:"fast",l:"Pack it all in",e:"🏃"}],
  },
  {
    id:"food", question:"Food matters how much?",
    options:[{v:"everything",l:"It's the whole trip",e:"🍽"},{v:"important",l:"Very important",e:"🌮"},{v:"fuel",l:"Just fuel",e:"⚡"}],
  },
  {
    id:"vibe", question:"What's your ideal trip vibe?",
    options:[{v:"relax",l:"Total relaxation",e:"🏖"},{v:"explore",l:"Discover everything",e:"🗺"},{v:"immerse",l:"Live like a local",e:"🏘"}],
  },
];

// Full quiz in Profile
const QUIZ_QUESTIONS = [
  {
    id:"pace", question:"Your ideal travel pace?",
    options:[{v:"slow",l:"Slow & savour",e:"🧘"},{v:"medium",l:"Balanced mix",e:"⚖"},{v:"fast",l:"Pack it all in",e:"🏃"}],
  },
  {
    id:"food", question:"Food matters how much?",
    options:[{v:"everything",l:"It's the whole trip",e:"🍽"},{v:"important",l:"Very important",e:"🌮"},{v:"fuel",l:"Just fuel",e:"⚡"}],
  },
  {
    id:"sleep", question:"When do you wake up on vacation?",
    options:[{v:"early",l:"6-8am, let's go",e:"🌅"},{v:"mid",l:"9-10am, perfect",e:"☀"},{v:"late",l:"11am+, no rush",e:"🌙"}],
  },
  {
    id:"crowd", question:"Your crowd tolerance?",
    options:[{v:"love",l:"Love the energy",e:"🎪"},{v:"some",l:"Some is fine",e:"🙂"},{v:"hate",l:"Avoid at all costs",e:"🌿"}],
  },
  {
    id:"style", question:"Your travel style?",
    options:[{v:"planner",l:"I plan everything",e:"📋"},{v:"flex",l:"Rough outline only",e:"🗺"},{v:"spontaneous",l:"Pure spontaneity",e:"🎲"}],
  },
  {
    id:"budget", question:"How do you travel budget-wise?",
    options:[{v:"luxury",l:"Only the best",e:"💎"},{v:"mid",l:"Comfort without excess",e:"✈"},{v:"budget",l:"Stretch every dollar",e:"🎒"}],
  },
  {
    id:"companions", question:"Who do you usually travel with?",
    options:[{v:"solo",l:"Solo — just me",e:"🧍"},{v:"partner",l:"Partner or best friend",e:"👫"},{v:"group",l:"The whole crew",e:"👥"}],
  },
  {
    id:"vibe", question:"What's your ideal trip vibe?",
    options:[{v:"relax",l:"Total relaxation",e:"🏖"},{v:"explore",l:"Discover everything",e:"🗺"},{v:"immerse",l:"Live like a local",e:"🏘"}],
  },
];

const EXPLORE_CITIES = [
  { city:"New Orleans", tag:"Jazz & soul",         emoji:"🎷", bg:"#2d1a0e", accent:"#c49a3c" },
  { city:"Tokyo",       tag:"Ancient meets future", emoji:"🗼", bg:"#0e1a2d", accent:"#c84b2f" },
  { city:"Barcelona",   tag:"Sun & Gaudí",          emoji:"🌊", bg:"#1a2d0e", accent:"#4a7c59" },
  { city:"Nashville",   tag:"Honky-tonk heart",     emoji:"🎸", bg:"#2d200e", accent:"#c49a3c" },
  { city:"Lisbon",      tag:"Fado & hills",          emoji:"🚋", bg:"#1a0e2d", accent:"#a04060" },
  { city:"Miami",       tag:"Heat & art",            emoji:"🌴", bg:"#0e2d20", accent:"#c84b2f" },
  { city:"Paris",       tag:"Romance & culture",     emoji:"🗼", bg:"#1a1a2d", accent:"#c49a3c" },
  { city:"Mexico City", tag:"Color & chaos",         emoji:"🌮", bg:"#2d1a0e", accent:"#c84b2f" },
  { city:"New York",    tag:"The city that never sleeps", emoji:"🗽", bg:"#0e0e1a", accent:"#4a7c59" },
  { city:"Kyoto",       tag:"Temples & cherry blossoms", emoji:"⛩", bg:"#1a0e0e", accent:"#a04060" },
  { city:"Amsterdam",   tag:"Canals & creativity",   emoji:"🚲", bg:"#0e1a1a", accent:"#4a7c59" },
  { city:"Buenos Aires",tag:"Tango & steak",         emoji:"💃", bg:"#2d0e1a", accent:"#c49a3c" },
  { city:"Cape Town",   tag:"Mountains meet ocean",  emoji:"🏔", bg:"#0e2d2d", accent:"#c84b2f" },
  { city:"Seoul",       tag:"K-culture & street food", emoji:"🏙", bg:"#1a1a0e", accent:"#a04060" },
  { city:"London",      tag:"History & cool",        emoji:"🎡", bg:"#0e0e2d", accent:"#c49a3c" },
  { city:"Marrakech",   tag:"Spice & color",         emoji:"🕌", bg:"#2d1a00", accent:"#c84b2f" },
];

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────
const MONTHS_SHORT = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const MONTHS_FULL  = ["January","February","March","April","May","June","July","August","September","October","November","December"];

export { T, FONTS, GLOBAL_CSS, NAV_H, TRANSIT_ICONS, TRANSIT_COLORS, VIBES, EXPLORE_CITIES, VIBE_COLORS_MAP, DNA_TYPES };