import { useState, useRef } from "react";
import { T, TRANSIT_ICONS, TRANSIT_COLORS } from "./constants.jsx";
function MomentCards({ day, activeDay, ratings, activeSlot, checkIn, checkOut, setSelectedPlace, BUCKET_COLORS, getBucket, TRANSIT_ICONS, TRANSIT_COLORS, onUpdateSlots }) {
  const [activeSlotIdx, setActiveSlotIdx] = useState(0);
  const [editingTime, setEditingTime] = useState(false);
  const [timeInput, setTimeInput] = useState("");
  const [timeValidating, setTimeValidating] = useState(false);
  const [timeMsg, setTimeMsg] = useState(null);
  const slots = day.slots || [];
  const slot = slots[activeSlotIdx];
  const slotKey = `${activeDay}-${activeSlotIdx}`;
  const isActive = activeSlot === slotKey;
  const rating = ratings[slotKey];
  const isCompleted = rating !== undefined;
  const bc = BUCKET_COLORS[getBucket(slot?.time)];

  const openTimeEdit = (e) => {
    e.stopPropagation();
    setTimeInput(slot.time || "");
    setTimeMsg(null);
    setEditingTime(true);
  };

  const validateTime = async () => {
    if (!timeInput.trim()) return;
    setTimeValidating(true);
    setTimeMsg(null);
    try {
      const res = await fetch("http://192.168.12.108:3001/validate-time", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          slot: { name: slot.name, time: slot.time, end_time: slot.end_time, category: slot.category },
          newTime: timeInput.trim(),
          allSlots: slots.map(s => ({ name: s.name, time: s.time, end_time: s.end_time }))
        })
      });
      const data = await res.json();
      if (data.feasible) {
        // Apply the time change
        const updatedSlots = slots.map((s, i) =>
          i === activeSlotIdx ? { ...s, time: data.newTime || timeInput, end_time: data.newEndTime || s.end_time } : s
        );
        onUpdateSlots(updatedSlots);
        setTimeMsg({ type: "ok", text: data.message });
        setTimeout(() => { setEditingTime(false); setTimeMsg(null); }, 1500);
      } else {
        setTimeMsg({ type: "warn", text: data.message });
      }
    } catch(e) {
      setTimeMsg({ type: "warn", text: "Couldn't validate — try again." });
    }
    setTimeValidating(false);
  };

  // Touch swipe handling
  const touchStartX = useRef(null);
  const handleTouchStart = (e) => { touchStartX.current = e.touches[0].clientX; };
  const handleTouchEnd = (e) => {
    if (touchStartX.current === null) return;
    const diff = touchStartX.current - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) {
      if (diff > 0 && activeSlotIdx < slots.length-1) setActiveSlotIdx(i=>i+1);
      if (diff < 0 && activeSlotIdx > 0) setActiveSlotIdx(i=>i-1);
    }
    touchStartX.current = null;
  };

  // Progress dots colors by bucket
  const bucketGradients = {
    morning: "linear-gradient(135deg,#f5e6c8,#e8c97a)",
    afternoon: "linear-gradient(135deg,#c8e8d4,#4a7c59)",
    evening: "linear-gradient(135deg,#2d1a2d,#8b1a4a)"
  };
  const bucket = getBucket(slot?.time);
  const cardBg = isCompleted ? "#f0f0f0" : isActive ? T.sage : slot?.highlight ? T.ink : bucketGradients[bucket] || T.white;
  const textColor = (slot?.highlight || isActive || bucket==="evening") && !isCompleted ? "white" : T.ink;
  const subtextColor = (slot?.highlight || isActive || bucket==="evening") && !isCompleted ? "rgba(255,255,255,0.6)" : T.inkFaint;

  if (!slot) return null;

  return (
    <div style={{padding:"12px 16px 0"}}>
      {/* Story progress bars */}
      <div style={{display:"flex",gap:4,marginBottom:12}}>
        {slots.map((_,i)=>(
          <div key={i} onClick={()=>setActiveSlotIdx(i)} style={{flex:1,height:3,borderRadius:2,background:"rgba(0,0,0,0.08)",cursor:"pointer",overflow:"hidden"}}>
            <div style={{height:"100%",borderRadius:2,background:ratings[`${activeDay}-${i}`]!==undefined?T.sage:i===activeSlotIdx?bc:"rgba(0,0,0,0.12)",width:ratings[`${activeDay}-${i}`]!==undefined||i<activeSlotIdx?"100%":i===activeSlotIdx?"100%":"0%",transition:"width 0.3s"}}/>
          </div>
        ))}
      </div>

      {/* Main moment card */}
      <div
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        style={{borderRadius:24,overflow:"hidden",boxShadow:"0 12px 40px rgba(28,22,18,0.15)",marginBottom:12,minHeight:480,display:"flex",flexDirection:"column",position:"relative",background:isCompleted?"#f0f0f0":isActive?T.sage:slot.highlight?T.ink:T.white,cursor:"pointer"}}
        onClick={()=>setSelectedPlace({name:slot.name,category:slot.category})}>

        {/* Hero photo — full bleed */}
        {slot.photo ? (
          <div style={{position:"relative",height:280,flexShrink:0}}>
            <img src={slot.photo} alt={slot.name} style={{width:"100%",height:"100%",objectFit:"cover"}} onError={e=>e.target.parentNode.style.background=T.ink}/>
            <div style={{position:"absolute",inset:0,background:"linear-gradient(to bottom,rgba(0,0,0,0.1) 0%,transparent 40%,rgba(28,22,18,0.8) 100%)"}}/>
            {/* Time overlay */}
            <div style={{position:"absolute",top:16,left:16,display:"flex",gap:6}} onClick={e=>e.stopPropagation()}>
              <button onClick={openTimeEdit} style={{background:"rgba(0,0,0,0.5)",backdropFilter:"blur(8px)",border:"1.5px dashed rgba(255,255,255,0.5)",color:"white",fontSize:12,fontWeight:700,padding:"5px 12px",borderRadius:20,cursor:"pointer",display:"flex",alignItems:"center",gap:5}}>
                <span>🕐</span>
                <span>{slot.time}</span>
                <span style={{fontSize:9,opacity:0.6,marginLeft:1}}>▾</span>
              </button>
              {slot.price&&<span style={{background:"rgba(0,0,0,0.5)",backdropFilter:"blur(8px)",color:"white",fontSize:11,fontWeight:700,padding:"4px 10px",borderRadius:20}}>{slot.price}</span>}
              {slot.highlight&&<span style={{background:T.gold,color:"white",fontSize:11,fontWeight:700,padding:"4px 10px",borderRadius:20}}>★ Must-do</span>}
            </div>
            {/* Name on photo */}
            <div style={{position:"absolute",bottom:16,left:16,right:16}}>
              <div style={{fontFamily:"'Playfair Display',serif",fontSize:26,fontWeight:700,color:"white",lineHeight:1.2,marginBottom:4}}>{slot.name}</div>
              <div style={{fontSize:12,color:"rgba(255,255,255,0.7)",display:"flex",alignItems:"center",gap:4}}>
                <span>📍</span>{slot.neighborhood}
              </div>
            </div>
          </div>
        ) : (
          // No photo — colored background with big text
          <div style={{padding:"28px 24px 20px",background:isCompleted?"#f0f0f0":slot.highlight?T.ink:bc,flex:"0 0 auto"}}>
            <div style={{display:"flex",gap:6,marginBottom:16}} onClick={e=>e.stopPropagation()}>
              <button onClick={openTimeEdit} style={{background:"rgba(255,255,255,0.15)",border:"1.5px dashed rgba(255,255,255,0.5)",color:"white",fontSize:12,fontWeight:700,padding:"5px 12px",borderRadius:20,cursor:"pointer",display:"flex",alignItems:"center",gap:5}}>
                <span>🕐</span>
                <span>{slot.time}</span>
                <span style={{fontSize:9,opacity:0.6,marginLeft:1}}>▾</span>
              </button>
              {slot.price&&<span style={{background:"rgba(255,255,255,0.15)",color:"white",fontSize:11,fontWeight:700,padding:"4px 10px",borderRadius:20}}>{slot.price}</span>}
              {slot.highlight&&<span style={{background:T.gold,color:"white",fontSize:11,fontWeight:700,padding:"4px 10px",borderRadius:20}}>★ Must-do</span>}
            </div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:30,fontWeight:700,color:"white",lineHeight:1.15,marginBottom:6}}>{slot.name}</div>
            <div style={{fontSize:12,color:"rgba(255,255,255,0.6)",display:"flex",alignItems:"center",gap:4}}>
              <span>📍</span>{slot.neighborhood}
            </div>
          </div>
        )}

        {/* Content area */}
        <div style={{padding:"20px 20px 16px",flex:1,display:"flex",flexDirection:"column",gap:12,background:isCompleted?"#f8f8f8":isActive?T.sage:slot.highlight?T.ink:T.white}}>
          {/* Activity */}
          <div style={{fontSize:15,color:slot.highlight||isActive?"rgba(255,255,255,0.85)":T.inkLight,lineHeight:1.65,fontStyle:"italic"}}>{slot.activity}</div>

          {/* Tip */}
          {slot.must_know&&(
            <div style={{background:slot.highlight||isActive?"rgba(255,255,255,0.1)":"#fdf5e6",borderRadius:12,padding:"10px 14px",fontSize:13,color:slot.highlight||isActive?"rgba(255,255,255,0.7)":"#7a5c2a",fontWeight:600,display:"flex",gap:8,alignItems:"flex-start"}}>
              <span style={{flexShrink:0}}>💡</span><span>{slot.must_know}</span>
            </div>
          )}

          {/* Transit */}
          {/* Transit to NEXT stop */}
          {activeSlotIdx < slots.length - 1 && (() => {
            const nextSlot = slots[activeSlotIdx + 1];
            const mode = nextSlot?.transit_mode || "walk";
            const modeLabel = ({walk:"On foot",subway:"Subway",taxi:"Taxi",uber:"Uber",lyft:"Lyft",bus:"Bus",tram:"Tram","tuk-tuk":"Tuk-tuk",ferry:"Ferry",bike:"Bike",drive:"By car"})[mode] || mode;
            const mins = (nextSlot?.transit_from_prev||"").match(/\d+/)?.[0];
            if (!nextSlot?.transit_from_prev) return null;
            return (
              <div style={{display:"flex",alignItems:"center",gap:10,borderRadius:12,padding:"10px 14px",background:slot.highlight||isActive?"rgba(255,255,255,0.08)":"rgba(0,0,0,0.04)",border:`1px solid ${slot.highlight||isActive?"rgba(255,255,255,0.1)":"rgba(0,0,0,0.06)"}`}}>
                {mode==="uber" ? (
                  <div style={{width:30,height:30,borderRadius:8,background:"#000",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                    <span style={{fontSize:13,fontWeight:900,color:"white",fontFamily:"Arial"}}>U</span>
                  </div>
                ) : mode==="lyft" ? (
                  <div style={{width:30,height:30,borderRadius:8,background:"#ea0083",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                    <span style={{fontSize:13,fontWeight:900,color:"white",fontFamily:"Arial"}}>L</span>
                  </div>
                ) : (
                  <span style={{fontSize:22,lineHeight:1,flexShrink:0}}>{TRANSIT_ICONS[mode]||"🚶"}</span>
                )}
                <div style={{flex:1}}>
                  <div style={{display:"flex",alignItems:"center",gap:0}}>
                    <span style={{fontSize:13,fontWeight:700,color:slot.highlight||isActive?"white":TRANSIT_COLORS[mode]||T.sage}}>{modeLabel}</span>
                    <span style={{margin:"0 8px",color:slot.highlight||isActive?"rgba(255,255,255,0.2)":"#ddd",fontSize:14}}>|</span>
                    <span style={{fontSize:13,fontWeight:600,color:slot.highlight||isActive?"rgba(255,255,255,0.7)":"#666"}}>{mins} min</span>
                  </div>
                  <div style={{fontSize:10,color:slot.highlight||isActive?"rgba(255,255,255,0.3)":"#bbb",marginTop:1}}>
                    to {nextSlot.name}
                  </div>
                </div>
                <span style={{fontSize:11,color:slot.highlight||isActive?"rgba(255,255,255,0.3)":"#bbb"}}>→</span>
              </div>
            );
          })()}

          {/* Tap hint */}
          <div style={{fontSize:11,color:slot.highlight||isActive?"rgba(255,255,255,0.25)":T.dust,textAlign:"center",fontStyle:"italic"}}>
            Tap card for Google reviews & hours
          </div>

          <div style={{flex:1}}/>

          {/* Action buttons */}
          <div style={{display:"flex",gap:8}} onClick={e=>e.stopPropagation()}>
            {isCompleted ? (
              <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",gap:4,padding:"12px 0",background:"rgba(74,124,89,0.1)",borderRadius:14}}>
                {[1,2,3,4,5].map(s=><span key={s} style={{fontSize:18,color:s<=rating?T.gold:T.dust}}>★</span>)}
              </div>
            ) : isActive ? (
              <button onClick={()=>checkOut(activeDay,activeSlotIdx,slot)}
                style={{flex:1,padding:"14px 0",borderRadius:14,background:"rgba(255,255,255,0.15)",border:"1.5px solid rgba(255,255,255,0.3)",color:"white",fontSize:14,fontWeight:700,cursor:"pointer"}}>
                Done here — rate it →
              </button>
            ) : (
              <>
                <button onClick={()=>checkIn(activeDay,activeSlotIdx)}
                  style={{flex:1,padding:"13px 0",borderRadius:14,background:slot.highlight?T.gold:T.sage,border:"none",color:"white",fontSize:13,fontWeight:700,cursor:"pointer"}}>
                  I'm here →
                </button>
                <button onClick={(e)=>{e.stopPropagation();setSelectedPlace({name:slot.name,category:slot.category});}}
                  style={{padding:"13px 16px",borderRadius:14,background:"rgba(255,255,255,0.1)",border:"1px solid rgba(255,255,255,0.15)",color:slot.highlight||isActive?"white":T.inkFaint,fontSize:12,fontWeight:600,cursor:"pointer",whiteSpace:"nowrap"}}>
                  Reviews & hours
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Time edit modal */}
      {editingTime && (
        <div style={{position:"fixed",inset:0,background:"rgba(28,22,18,0.7)",zIndex:400,display:"flex",alignItems:"flex-end",justifyContent:"center",animation:"fadeIn 0.2s ease"}} onClick={()=>setEditingTime(false)}>
          <div onClick={e=>e.stopPropagation()} style={{background:T.white,borderRadius:"24px 24px 0 0",width:"100%",maxWidth:480,padding:"24px 20px 40px",fontFamily:"'DM Sans',sans-serif",animation:"slideUp 0.3s ease"}}>
            <div style={{width:36,height:4,borderRadius:2,background:T.dust,margin:"0 auto 20px"}}/>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:700,color:T.ink,marginBottom:4}}>{slot.name}</div>
            <div style={{fontSize:13,color:T.inkFaint,marginBottom:20}}>Current time: {slot.time} – {slot.end_time}</div>

            <div style={{fontSize:13,fontWeight:600,color:T.inkLight,marginBottom:8}}>Move to what time?</div>
            <input
              value={timeInput}
              onChange={e=>setTimeInput(e.target.value)}
              onKeyDown={e=>e.key==="Enter"&&validateTime()}
              placeholder="e.g. 3:00 PM or 15:00"
              style={{width:"100%",padding:"14px 16px",borderRadius:14,border:`1.5px solid ${T.dust}`,background:T.cream,color:T.ink,fontSize:16,outline:"none",marginBottom:12,textAlign:"center"}}/>

            {/* Quick time suggestions */}
            <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:16}}>
              {["8:00 AM","9:00 AM","10:00 AM","12:00 PM","1:00 PM","2:00 PM","3:00 PM","5:00 PM","7:00 PM","8:00 PM","9:00 PM"].map(t=>(
                <button key={t} onClick={()=>setTimeInput(t)}
                  style={{padding:"6px 12px",borderRadius:20,border:`1.5px solid ${timeInput===t?T.accent:T.dust}`,background:timeInput===t?T.accent:"transparent",color:timeInput===t?"white":T.inkLight,fontSize:12,fontWeight:600,cursor:"pointer"}}>
                  {t}
                </button>
              ))}
            </div>

            {timeMsg && (
              <div style={{padding:"10px 14px",borderRadius:12,background:timeMsg.type==="ok"?"#eaf6f0":"#fef5e7",marginBottom:12,fontSize:13,color:timeMsg.type==="ok"?T.sage:"#7a5c2a",fontWeight:600,lineHeight:1.5}}>
                {timeMsg.type==="ok"?"✓":"⚠"} {timeMsg.text}
              </div>
            )}

            <button onClick={validateTime} disabled={!timeInput.trim()||timeValidating}
              style={{width:"100%",padding:15,borderRadius:16,background:timeInput.trim()?T.ink:T.dust,border:"none",color:"white",fontSize:15,fontWeight:700,cursor:timeInput.trim()?"pointer":"default"}}>
              {timeValidating?"Checking feasibility…":"Move to this time →"}
            </button>
          </div>
        </div>
      )}

      {/* Swipe hint + slot counter */}
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 4px",marginBottom:NAV_H+60}}>
        <button onClick={()=>activeSlotIdx>0&&setActiveSlotIdx(i=>i-1)}
          style={{background:"none",border:"none",color:activeSlotIdx>0?T.inkLight:T.dust,fontSize:13,fontWeight:600,cursor:activeSlotIdx>0?"pointer":"default",padding:"6px 0"}}>
          {activeSlotIdx>0?"← Previous":""}
        </button>
        <div style={{fontSize:12,color:T.inkFaint}}>{activeSlotIdx+1} of {slots.length}</div>
        <button onClick={()=>activeSlotIdx<slots.length-1&&setActiveSlotIdx(i=>i+1)}
          style={{background:"none",border:"none",color:activeSlotIdx<slots.length-1?T.inkLight:T.dust,fontSize:13,fontWeight:600,cursor:activeSlotIdx<slots.length-1?"pointer":"default",padding:"6px 0"}}>
          {activeSlotIdx<slots.length-1?"Next →":""}
        </button>
      </div>
    </div>
  );
}

export { MomentCards };