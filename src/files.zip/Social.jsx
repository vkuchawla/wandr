import { useState, useEffect } from "react";
import { T, GLOBAL_CSS, NAV_H, VIBE_COLORS_MAP } from "./constants.jsx";
function parseVibesFromContext(moodCtx) {
  if (!moodCtx) return [];
  const all = [];
  moodCtx.split("\n").forEach(line => {
    const vibes = line.split(":")[1]?.split(",").map(v => v.trim()).filter(Boolean) || [];
    vibes.forEach(v => { if (!all.includes(v)) all.push(v); });
  });
  return all.slice(0, 5);
}

function TripCard({ trip, i, user, following, followUser, onRemix }) {
  const vibes = parseVibesFromContext(trip.mood_context);
  const isFollowing = following.includes(trip.user_id);
  const isOwnTrip = user && trip.user_id === user.id;

  return (
    <div style={{background:T.white,borderRadius:20,marginBottom:12,overflow:"hidden",boxShadow:"0 2px 12px rgba(28,22,18,0.06)",animation:`fadeUp 0.4s ease ${i*0.04}s both`}}>
      <div style={{background:`linear-gradient(135deg,${T.ink},#2d1f10)`,padding:"16px 18px"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:34,height:34,borderRadius:"50%",background:isOwnTrip?T.gold:T.accent,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:800,color:T.white,flexShrink:0}}>
              {trip.profiles?.name?.[0] || "?"}
            </div>
            <div>
              <div style={{fontSize:13,fontWeight:700,color:T.white}}>{isOwnTrip ? "You" : (trip.profiles?.name || "Wanderer")}</div>
              {trip.profiles?.travel_dna && <div style={{fontSize:10,color:"rgba(255,255,255,0.4)"}}>{trip.profiles.travel_dna}</div>}
            </div>
          </div>
          {user && !isOwnTrip && (
            <button onClick={()=>followUser(trip.user_id)}
              style={{padding:"5px 12px",borderRadius:14,background:isFollowing?"rgba(255,255,255,0.1)":"rgba(200,75,47,0.8)",border:`1px solid ${isFollowing?"rgba(255,255,255,0.15)":T.accent}`,color:T.white,fontSize:11,fontWeight:700,cursor:"pointer"}}>
              {isFollowing ? "Following ✓" : "Follow"}
            </button>
          )}
        </div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:700,color:T.white}}>{trip.city}</div>
        <div style={{fontSize:12,color:"rgba(255,255,255,0.35)",marginTop:2}}>
          {trip.dates} · {Array.isArray(trip.days) ? trip.days.length : 0} days
        </div>
      </div>

      {vibes.length > 0 && (
        <div style={{padding:"12px 18px 0",display:"flex",flexWrap:"wrap",gap:6}}>
          {vibes.map(v=>{
            const key = v.toLowerCase().replace(/ /g,"-");
            const color = VIBE_COLORS_MAP[key] || T.inkFaint;
            return (
              <span key={v} style={{padding:"4px 10px",borderRadius:12,background:`${color}18`,fontSize:11,fontWeight:700,color}}>
                {v}
              </span>
            );
          })}
        </div>
      )}

      <div style={{padding:"12px 18px 16px",display:"flex",gap:8}}>
        {!isOwnTrip && (
          <button onClick={()=>onRemix(trip)}
            style={{flex:1,padding:"10px 0",borderRadius:12,background:T.ink,border:"none",color:T.white,fontSize:13,fontWeight:700,cursor:"pointer"}}>
            ✦ Remix this trip
          </button>
        )}
        {isOwnTrip && (
          <div style={{flex:1,padding:"10px 0",borderRadius:12,background:T.paper,fontSize:13,fontWeight:600,color:T.inkFaint,textAlign:"center"}}>
            Your trip
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// SOCIAL SCREEN
// ─────────────────────────────────────────────
function SocialScreen({ supabase, user, onRemix }) {
  const [tab, setTab]             = useState("feed");
  const [feed, setFeed]           = useState([]);
  const [discover, setDiscover]   = useState([]);
  const [search, setSearch]       = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [following, setFollowing] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [loading, setLoading]     = useState(true);

  useEffect(() => { loadFollowing(); }, []);
  useEffect(() => { if (following !== null) loadFeed(); }, [following]);

  const loadFeed = async () => {
    setLoading(true);
    // Friends feed — trips from people you follow + your own
    const ids = [...following, ...(user ? [user.id] : [])];
    if (ids.length > 0) {
      const { data } = await supabase
        .from("trips")
        .select("*, profiles(name, username, travel_dna)")
        .in("user_id", ids)
        .eq("is_public", true)
        .order("saved_at", { ascending: false })
        .limit(20);
      setFeed(data || []);
    } else {
      setFeed([]);
    }
    // Discover feed — everyone else
    const { data: all } = await supabase
      .from("trips")
      .select("*, profiles(name, username, travel_dna)")
      .eq("is_public", true)
      .order("saved_at", { ascending: false })
      .limit(20);
    setDiscover(all || []);
    setLoading(false);
  };

  const loadFollowing = async () => {
    if (!user) { setFollowing([]); return; }
    const [{ data: fwing }, { data: fwers }] = await Promise.all([
      supabase.from("follows").select("following_id").eq("follower_id", user.id),
      supabase.from("follows").select("follower_id, profiles(name, travel_dna)").eq("following_id", user.id)
    ]);
    setFollowing((fwing || []).map(f => f.following_id));
    setFollowers(fwers || []);
  };

  const followUser = async (userId) => {
    if (!user) return;
    if (following.includes(userId)) {
      await supabase.from("follows").delete().eq("follower_id", user.id).eq("following_id", userId);
      setFollowing(prev => prev.filter(id => id !== userId));
    } else {
      await supabase.from("follows").insert({ follower_id: user.id, following_id: userId });
      setFollowing(prev => [...prev, userId]);
    }
  };

  const searchUsers = async (q) => {
    setSearch(q);
    if (q.length < 2) { setSearchResults([]); return; }
    const { data, error } = await supabase
      .from("profiles")
      .select("id, name, username, travel_dna")
      .ilike("name", `%${q}%`)
      .limit(8);
    console.log("Search results:", data, error);
    setSearchResults(data || []);
  };

  const parseVibes = (moodCtx) => parseVibesFromContext(moodCtx);

  return (
    <div style={{minHeight:"100vh",background:T.cream,fontFamily:"'DM Sans',sans-serif",paddingBottom:NAV_H}}>
      <style>{GLOBAL_CSS}</style>

      {/* Header */}
      <div style={{padding:"56px 20px 16px",background:T.ink}}>
        <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.22em",textTransform:"uppercase",color:"rgba(196,154,60,0.7)",marginBottom:10}}>✦ FRIENDS</div>
        <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:28,fontWeight:700,color:T.white,marginBottom:16}}>Where friends wander.</h1>

        {/* Tabs */}
        <div style={{display:"flex",gap:8,overflowX:"auto"}}>
          {[["feed","Friends"],["discover","Discover"],["followers","Followers"],["find","Find"]].map(([t,label])=>(
            <button key={t} onClick={()=>setTab(t)}
              style={{flexShrink:0,padding:"8px 16px",borderRadius:20,background:tab===t?"rgba(255,255,255,0.12)":"transparent",border:`1px solid ${tab===t?"rgba(255,255,255,0.2)":"rgba(255,255,255,0.08)"}`,color:tab===t?T.white:"rgba(255,255,255,0.4)",fontSize:12,fontWeight:700,cursor:"pointer"}}>
              {label}{t==="followers"&&followers.length>0?` (${followers.length})`:""}
            </button>
          ))}
        </div>
      </div>

      {/* Friends feed — people you follow */}
      {tab === "feed" && (
        <div style={{padding:"16px 16px"}}>
          {loading ? (
            <div style={{textAlign:"center",padding:40,color:T.inkFaint,fontSize:14}}>Loading…</div>
          ) : feed.length === 0 ? (
            <div style={{textAlign:"center",padding:40}}>
              <div style={{fontSize:36,marginBottom:12}}>👥</div>
              <div style={{fontSize:15,fontWeight:700,color:T.ink,marginBottom:8}}>No trips from friends yet</div>
              <div style={{fontSize:13,color:T.inkFaint,lineHeight:1.6}}>Follow some friends to see their trips here, or check Discover for inspiration.</div>
            </div>
          ) : feed.map((trip, i) => <TripCard key={trip.id} trip={trip} i={i} user={user} following={following} followUser={followUser} onRemix={onRemix}/>)}
        </div>
      )}

      {/* Discover — all public trips */}
      {tab === "discover" && (
        <div style={{padding:"16px 16px"}}>
          {loading ? (
            <div style={{textAlign:"center",padding:40,color:T.inkFaint,fontSize:14}}>Loading…</div>
          ) : discover.map((trip, i) => <TripCard key={trip.id} trip={trip} i={i} user={user} following={following} followUser={followUser} onRemix={onRemix}/>)}
        </div>
      )}

      {/* Followers */}
      {tab === "followers" && (
        <div style={{padding:"16px"}}>
          {followers.length === 0 ? (
            <div style={{textAlign:"center",padding:40}}>
              <div style={{fontSize:36,marginBottom:12}}>🌱</div>
              <div style={{fontSize:15,fontWeight:700,color:T.ink,marginBottom:8}}>No followers yet</div>
              <div style={{fontSize:13,color:T.inkFaint}}>Share your trips and people will find you.</div>
            </div>
          ) : followers.map(f => (
            <div key={f.follower_id} style={{background:T.white,borderRadius:16,padding:"14px 16px",marginBottom:8,display:"flex",alignItems:"center",gap:12,border:`1px solid ${T.dust}`}}>
              <div style={{width:40,height:40,borderRadius:"50%",background:T.sage,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:800,color:T.white,flexShrink:0}}>
                {f.profiles?.name?.[0] || "?"}
              </div>
              <div style={{flex:1}}>
                <div style={{fontSize:14,fontWeight:700,color:T.ink}}>{f.profiles?.name || "Wanderer"}</div>
                {f.profiles?.travel_dna && <div style={{fontSize:11,color:T.inkFaint}}>{f.profiles.travel_dna}</div>}
              </div>
              <div style={{fontSize:12,color:T.inkFaint}}>follows you</div>
            </div>
          ))}
        </div>
      )}
      {/* Find friends tab */}
      {tab === "find" && (
        <div style={{padding:"16px"}}>
          <input value={search} onChange={e=>searchUsers(e.target.value)}
            placeholder="Search by name…"
            style={{width:"100%",padding:"13px 16px",borderRadius:14,border:`1.5px solid ${T.dust}`,background:T.white,color:T.ink,fontSize:15,outline:"none",marginBottom:12}}/>
          {searchResults.map(u=>(
            <div key={u.id} style={{background:T.white,borderRadius:16,padding:"14px 16px",marginBottom:8,display:"flex",alignItems:"center",gap:12,border:`1px solid ${T.dust}`}}>
              <div style={{width:40,height:40,borderRadius:"50%",background:T.accent,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:800,color:T.white,flexShrink:0}}>
                {u.name?.[0] || "?"}
              </div>
              <div style={{flex:1}}>
                <div style={{fontSize:14,fontWeight:700,color:T.ink}}>{u.name}</div>
                {u.travel_dna && <div style={{fontSize:11,color:T.inkFaint}}>{u.travel_dna}</div>}
              </div>
              {user && u.id !== user.id && (
                <button onClick={()=>followUser(u.id)}
                  style={{padding:"7px 16px",borderRadius:12,background:following.includes(u.id)?T.paper:T.ink,border:`1px solid ${following.includes(u.id)?T.dust:"transparent"}`,color:following.includes(u.id)?T.inkLight:T.white,fontSize:12,fontWeight:700,cursor:"pointer"}}>
                  {following.includes(u.id) ? "Following" : "Follow"}
                </button>
              )}
            </div>
          ))}
          {search.length >= 2 && searchResults.length === 0 && (
            <div style={{textAlign:"center",padding:"24px 0",color:T.inkFaint,fontSize:13}}>No users found for "{search}"</div>
          )}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// AUTH GATE MODAL — shown when action requires login
// ─────────────────────────────────────────────
export { parseVibesFromContext, TripCard, SocialScreen };