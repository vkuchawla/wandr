import { useState, useEffect, useRef } from "react";
import { T, GLOBAL_CSS, NAV_H, TRANSIT_ICONS, TRANSIT_COLORS } from "./constants.jsx";
import { MomentCards } from "./MomentCards.jsx";
import { PlaceSheet } from "./PlaceSheet.jsx";
import { ShareCard } from "./ShareCard.jsx";
import { parseTripDays, countDays } from "./utils.jsx";
function ItineraryView({ city, dates, moodContext, profile, onBack, onSave, preloadedDays }) {
  const [daysData, setDaysData]   = useState(preloadedDays || []);
  const [status, setStatus]       = useState(preloadedDays?.length > 0 ? "done" : "loading");
  const [statusMsg, setStatusMsg] = useState("");
  const [activeDay, setActiveDay] = useState(0);
  const [loadingDay, setLoadingDay] = useState(1);
  const [showShare, setShowShare] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState(null);
  const [showChat, setShowChat]   = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [tripSaved, setTripSaved] = useState(false);
  const [activeSlot, setActiveSlot] = useState(null); // index of slot user is currently at
  const [ratings, setRatings]     = useState({}); // { "dayIdx-slotIdx": 1-5 }
  const [showRating, setShowRating] = useState(null); // { dayIdx, slotIdx, slot }
  const [showDaySummary, setShowDaySummary] = useState(null); // day data after completion
  const savedRef = useRef(false);

  const totalDays = countDays(dates);
  const dayVibes  = moodContext.split("\n").filter(Boolean);

  const BACKEND = "http://192.168.12.108:3001";

  const generate = async () => {
    setStatus("loading"); setDaysData([]); setActiveDay(0); savedRef.current=false;
    setStatusMsg(`Building your ${totalDays}-day trip…`);

    // Generate all days in parallel — much faster than sequential
    const dayPromises = Array.from({ length: totalDays }, (_, i) => {
      const d = i + 1;
      return fetch(`${BACKEND}/itinerary/day`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city, dates, dayNum: d, dayVibe: dayVibes[d-1] || "open / flexible", totalDays, travelProfile: profile?.answers || null })
      })
        .then(r => r.ok ? r.json() : r.json().then(e => Promise.reject(e.error || "Error")))
        .then(dayData => {
          // Add each day as it completes so UI updates progressively
          setDaysData(prev => {
            const next = [...prev];
            next[i] = dayData;
            const filled = next.filter(Boolean);
            if (filled.length === 1) { setStatus("partial"); setActiveDay(0); }
            setLoadingDay(filled.length + 1);
            return next;
          });
          return dayData;
        })
        .catch(e => { console.error(`Day ${d} error:`, e); return null; });
    });

    await Promise.all(dayPromises);
    setDaysData(prev => prev.filter(Boolean));
    setStatus("done");
  };

  useEffect(()=>{ if (!preloadedDays?.length) generate(); }, []);

  const sendChat = async (msg) => {
    if (!msg.trim() || chatLoading) return;
    const day = daysData[activeDay];
    if (!day) return;
    setChatMessages(prev => [...prev, { role:"user", text:msg }]);
    setChatInput("");
    setChatLoading(true);
    try {
      const res = await fetch(`${BACKEND}/chat-edit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          city,
          message: msg,
          currentDay: day,
          profile: profile?.answers || null
        })
      });
      const data = await res.json();
      if (data.updatedDay) {
        setDaysData(prev => prev.map((d, i) => i === activeDay ? data.updatedDay : d));
        setChatMessages(prev => [...prev, { role:"assistant", text: data.message || "Done! I've updated your itinerary." }]);
      } else {
        setChatMessages(prev => [...prev, { role:"assistant", text: data.message || "I couldn't make that change. Try rephrasing." }]);
      }
    } catch(e) {
      setChatMessages(prev => [...prev, { role:"assistant", text:"Something went wrong. Try again." }]);
    }
    setChatLoading(false);
  };

  const saveTrip = () => {
    if (tripSaved) return;
    onSave({ city, dates, moodContext, days:daysData, emoji:"✦", savedAt:Date.now() });
    setTripSaved(true);
  };

  const checkIn = (dayIdx, slotIdx) => {
    setActiveSlot(`${dayIdx}-${slotIdx}`);
  };

  const checkOut = (dayIdx, slotIdx, slot) => {
    setActiveSlot(null);
    setShowRating({ dayIdx, slotIdx, slot });
  };

  const submitRating = (dayIdx, slotIdx, stars) => {
    const key = `${dayIdx}-${slotIdx}`;
    setRatings(prev => ({ ...prev, [key]: stars }));
    setShowRating(null);
    // Check if all slots in the day are rated
    const day = daysData[dayIdx];
    const allRated = day?.slots?.every((_, si) => {
      const k = `${dayIdx}-${si}`;
      return k === key || ratings[k];
    });
    if (allRated) {
      setTimeout(() => setShowDaySummary({ day, dayIdx }), 400);
    }
  };

  const BUCKET_COLORS = {morning:"#c49a3c",afternoon:"#4a7c59",evening:"#8b1a2f"};
  const TRANSIT_ICONS = { walk:"🚶", subway:"🚇", taxi:"🚕", bus:"🚌", tram:"🚊", "tuk-tuk":"🛺", ferry:"🚢", bike:"🚲", car:"🚗" };
  const TRANSIT_COLORS = { walk:"#4a7c59", subway:"#1e6b8a", taxi:"#c49a3c", bus:"#5a2d82", tram:"#255c3f", "tuk-tuk":"#b5600a", ferry:"#1a3a6b", bike:"#4a7c59", car:"#555" };
  const getBucket = t => {
    if (!t) return "morning";
    const h=parseInt(t.split(":")[0]); const pm=t.toLowerCase().includes("pm");
    const hour=pm&&h!==12?h+12:(!pm&&h===12?0:h);
    return hour<12?"morning":hour<17?"afternoon":"evening";
  };

  if (status==="error") return (
    <div style={{minHeight:"100vh",background:T.cream,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16,padding:32,fontFamily:"'DM Sans',sans-serif"}}>
      <style>{GLOBAL_CSS}</style>
      <div style={{fontSize:40}}>⚠</div>
      <div style={{fontSize:18,fontWeight:700,color:T.ink}}>Couldn't build itinerary</div>
      <div style={{fontSize:13,color:T.inkFaint,textAlign:"center",maxWidth:300,lineHeight:1.6,background:T.paper,padding:"12px 16px",borderRadius:12}}>{statusMsg||"Unknown error"}</div>
      <button onClick={generate} style={{padding:"12px 28px",borderRadius:14,background:T.ink,border:"none",color:T.white,fontSize:14,fontWeight:700,cursor:"pointer"}}>Try again</button>
      <button onClick={onBack} style={{padding:"10px 20px",borderRadius:14,background:"none",border:`1px solid ${T.dust}`,color:T.inkFaint,fontSize:13,cursor:"pointer"}}>← Back to mood board</button>
    </div>
  );

  if (status==="loading"&&daysData.length===0) {
    const tips = [
      "Consulting locals and insiders…",
      "Matching spots to your vibes…",
      "Finding hidden gems…",
      "Checking neighborhood timing…",
      "Crafting your day's narrative…",
      "Picking the must-do moment…",
    ];
    const tipIdx = Math.floor((Date.now() / 3000)) % tips.length;
    return (
      <div style={{minHeight:"100vh",background:T.ink,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:20,padding:32,fontFamily:"'DM Sans',sans-serif"}}>
        <style>{GLOBAL_CSS}</style>
        {/* Animated logo */}
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:56,color:T.white,animation:"pulse 2s ease infinite",marginBottom:4}}>✦</div>

        {/* City */}
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:28,fontWeight:700,color:T.white,textAlign:"center"}}>{city}</div>

        {/* Status */}
        <div style={{fontSize:14,fontWeight:600,color:"rgba(255,255,255,0.6)",textAlign:"center"}}>{statusMsg||"Building your itinerary…"}</div>

        {/* Rotating tip */}
        <div style={{fontSize:12,color:"rgba(255,255,255,0.3)",textAlign:"center",maxWidth:240,lineHeight:1.6,fontStyle:"italic",minHeight:36}}>
          {tips[tipIdx]}
        </div>

        {/* Day progress bars */}
        <div style={{display:"flex",gap:6,width:"100%",maxWidth:200,marginTop:4}}>
          {Array(totalDays).fill(null).map((_,i)=>(
            <div key={i} style={{flex:1,height:3,borderRadius:2,overflow:"hidden",background:"rgba(255,255,255,0.08)"}}>
              <div style={{
                height:"100%",borderRadius:2,
                transition:"width 0.6s ease",
                width:i<daysData.length?"100%":i===loadingDay-1?"50%":"0%",
                background:i<daysData.length?T.accent:"rgba(200,75,47,0.6)",
                animation:i===loadingDay-1?"shimmer 1.5s ease infinite":undefined,
                backgroundImage:i===loadingDay-1?`linear-gradient(90deg,rgba(200,75,47,0.3) 0%,${T.accent} 50%,rgba(200,75,47,0.3) 100%)`:undefined,
                backgroundSize:"200% auto"
              }}/>
            </div>
          ))}
        </div>

        {/* Day count */}
        <div style={{fontSize:11,color:"rgba(255,255,255,0.25)",letterSpacing:"0.1em",textTransform:"uppercase"}}>
          Day {loadingDay} of {totalDays}
        </div>
      </div>
    );
  }

  if (daysData.length===0) return (
    <div style={{minHeight:"100vh",background:T.cream,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16,padding:32,fontFamily:"'DM Sans',sans-serif"}}>
      <style>{GLOBAL_CSS}</style>
      <div style={{fontSize:40}}>⚠</div>
      <div style={{fontSize:18,fontWeight:700,color:T.ink}}>Something went wrong</div>
      <div style={{fontSize:13,color:T.inkFaint,textAlign:"center",maxWidth:300,lineHeight:1.6,background:T.paper,padding:"12px 16px",borderRadius:12}}>{statusMsg||"No data returned. Please try again."}</div>
      <button onClick={generate} style={{padding:"12px 28px",borderRadius:14,background:T.ink,border:"none",color:T.white,fontSize:14,fontWeight:700,cursor:"pointer"}}>Try again</button>
      <button onClick={onBack} style={{padding:"10px 20px",borderRadius:14,background:"none",border:`1px solid ${T.dust}`,color:T.inkFaint,fontSize:13,cursor:"pointer"}}>← Back to mood board</button>
    </div>
  );
  const day = daysData[activeDay];
  const stillLoading = status==="loading"||status==="partial";

  return (
    <div style={{minHeight:"100vh",background:T.cream,fontFamily:"'DM Sans',sans-serif",paddingBottom:NAV_H}}>
      <style>{GLOBAL_CSS}</style>

      {showShare && <ShareCard city={city} dates={dates} days={daysData} onClose={()=>setShowShare(false)}/>}
      {selectedPlace && <PlaceSheet place={selectedPlace.name} city={city} category={selectedPlace.category} BACKEND={BACKEND} onClose={()=>setSelectedPlace(null)}/>}

      {/* Rating modal */}
      {showRating && (
        <div style={{position:"fixed",inset:0,background:"rgba(28,22,18,0.7)",zIndex:300,display:"flex",alignItems:"flex-end",justifyContent:"center",animation:"fadeIn 0.2s ease"}} onClick={()=>setShowRating(null)}>
          <div onClick={e=>e.stopPropagation()} style={{background:T.white,borderRadius:"24px 24px 0 0",width:"100%",maxWidth:480,padding:"28px 24px 48px",animation:"slideUp 0.3s ease",fontFamily:"'DM Sans',sans-serif",textAlign:"center"}}>
            <div style={{width:36,height:4,borderRadius:2,background:T.dust,margin:"0 auto 20px"}}/>
            <div style={{fontSize:13,color:T.inkFaint,marginBottom:6}}>How was it?</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:700,color:T.ink,marginBottom:24}}>{showRating.slot.name}</div>
            <div style={{display:"flex",justifyContent:"center",gap:12,marginBottom:28}}>
              {[1,2,3,4,5].map(star=>(
                <button key={star} onClick={()=>submitRating(showRating.dayIdx, showRating.slotIdx, star)}
                  style={{fontSize:40,background:"none",border:"none",cursor:"pointer",transition:"transform 0.1s",lineHeight:1}}
                  onMouseEnter={e=>e.currentTarget.style.transform="scale(1.2)"}
                  onMouseLeave={e=>e.currentTarget.style.transform="scale(1)"}>
                  {star <= (ratings[`${showRating.dayIdx}-${showRating.slotIdx}`] || 0) ? "★" : "☆"}
                </button>
              ))}
            </div>
            <button onClick={()=>submitRating(showRating.dayIdx, showRating.slotIdx, 0)}
              style={{background:"none",border:"none",color:T.inkFaint,fontSize:13,cursor:"pointer",textDecoration:"underline"}}>
              Skip rating
            </button>
          </div>
        </div>
      )}

      {/* Day summary modal */}
      {showDaySummary && (
        <div style={{position:"fixed",inset:0,background:"rgba(28,22,18,0.75)",zIndex:300,display:"flex",alignItems:"flex-end",justifyContent:"center",animation:"fadeIn 0.2s ease"}}>
          <div style={{background:T.white,borderRadius:"24px 24px 0 0",width:"100%",maxWidth:480,padding:"28px 24px 48px",animation:"slideUp 0.3s ease",fontFamily:"'DM Sans',sans-serif"}}>
            <div style={{width:36,height:4,borderRadius:2,background:T.dust,margin:"0 auto 20px"}}/>
            <div style={{textAlign:"center",marginBottom:20}}>
              <div style={{fontSize:36,marginBottom:8}}>🌟</div>
              <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:24,fontWeight:700,color:T.ink,marginBottom:6}}>Day {showDaySummary.day.day} complete!</h2>
              <div style={{fontSize:13,color:T.inkFaint,fontStyle:"italic"}}>{showDaySummary.day.theme}</div>
            </div>
            {showDaySummary.day.slots?.map((slot, si)=>{
              const r = ratings[`${showDaySummary.dayIdx}-${si}`];
              return r ? (
                <div key={si} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 0",borderBottom:`1px solid ${T.dust}`}}>
                  <div style={{fontSize:14,fontWeight:600,color:T.ink}}>{slot.name}</div>
                  <div style={{display:"flex",gap:2}}>
                    {[1,2,3,4,5].map(s=>(
                      <span key={s} style={{fontSize:14,color:s<=r?T.gold:T.dust}}>★</span>
                    ))}
                  </div>
                </div>
              ) : null;
            })}
            <button onClick={()=>setShowDaySummary(null)}
              style={{width:"100%",marginTop:20,padding:15,borderRadius:16,background:T.ink,border:"none",color:T.white,fontSize:15,fontWeight:700,cursor:"pointer"}}>
              {showDaySummary.dayIdx < daysData.length-1 ? `On to Day ${showDaySummary.dayIdx+2} →` : "That's a wrap! ✦"}
            </button>
          </div>
        </div>
      )}

      {/* AI Chat Panel */}
      {showChat && (
        <div style={{position:"fixed",inset:0,background:"rgba(28,22,18,0.6)",zIndex:300,display:"flex",alignItems:"flex-end",justifyContent:"center",animation:"fadeIn 0.2s ease"}} onClick={()=>setShowChat(false)}>
          <div onClick={e=>e.stopPropagation()} style={{background:T.white,borderRadius:"24px 24px 0 0",width:"100%",maxWidth:480,height:"70vh",display:"flex",flexDirection:"column",animation:"slideUp 0.3s ease",fontFamily:"'DM Sans',sans-serif"}}>
            {/* Chat header */}
            <div style={{padding:"14px 20px 12px",borderBottom:`1px solid ${T.dust}`,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
              <div>
                <div style={{fontSize:15,fontWeight:700,color:T.ink}}>Edit Day {daysData[activeDay]?.day}</div>
                <div style={{fontSize:11,color:T.inkFaint}}>Ask me to add, remove or swap anything</div>
              </div>
              <button onClick={()=>setShowChat(false)} style={{background:"none",border:"none",fontSize:20,color:T.inkFaint,cursor:"pointer"}}>×</button>
            </div>

            {/* Suggestion chips */}
            {chatMessages.length === 0 && (
              <div style={{padding:"12px 16px",display:"flex",gap:8,flexWrap:"wrap",borderBottom:`1px solid ${T.dust}`}}>
                {["Add a rooftop bar after dinner","Make it more local, less touristy","Swap lunch for street food","Add a morning coffee stop","Make day more adventurous"].map(s=>(
                  <button key={s} onClick={()=>sendChat(s)}
                    style={{padding:"7px 12px",borderRadius:20,background:T.paper,border:`1px solid ${T.dust}`,fontSize:12,fontWeight:600,color:T.inkLight,cursor:"pointer",flexShrink:0}}>
                    {s}
                  </button>
                ))}
              </div>
            )}

            {/* Messages */}
            <div style={{flex:1,overflowY:"auto",padding:"16px"}}>
              {chatMessages.map((m,i)=>(
                <div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start",marginBottom:10}}>
                  <div style={{maxWidth:"80%",padding:"10px 14px",borderRadius:m.role==="user"?"18px 18px 4px 18px":"18px 18px 18px 4px",background:m.role==="user"?T.ink:T.paper,color:m.role==="user"?T.white:T.ink,fontSize:13,lineHeight:1.5}}>
                    {m.text}
                  </div>
                </div>
              ))}
              {chatLoading && (
                <div style={{display:"flex",justifyContent:"flex-start",marginBottom:10}}>
                  <div style={{padding:"10px 14px",borderRadius:"18px 18px 18px 4px",background:T.paper,color:T.inkFaint,fontSize:13,animation:"pulse 1s ease infinite"}}>
                    Updating your itinerary…
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div style={{padding:"12px 16px 28px",borderTop:`1px solid ${T.dust}`,display:"flex",gap:8}}>
              <input value={chatInput} onChange={e=>setChatInput(e.target.value)}
                onKeyDown={e=>e.key==="Enter"&&sendChat(chatInput)}
                placeholder="Add a jazz bar, swap dinner, make it more local…"
                style={{flex:1,padding:"12px 14px",borderRadius:14,border:`1.5px solid ${T.dust}`,background:T.cream,color:T.ink,fontSize:13,outline:"none"}}/>
              <button onClick={()=>sendChat(chatInput)} disabled={!chatInput.trim()||chatLoading}
                style={{padding:"12px 16px",borderRadius:14,background:chatInput.trim()?T.ink:T.dust,border:"none",color:T.white,fontSize:13,fontWeight:700,cursor:chatInput.trim()?"pointer":"default"}}>
                →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating chat button */}
      {status==="done" && !showChat && (
        <button onClick={()=>setShowChat(true)}
          style={{position:"fixed",bottom:NAV_H+16,right:20,width:52,height:52,borderRadius:"50%",background:T.ink,border:"none",boxShadow:"0 4px 20px rgba(28,22,18,0.25)",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,zIndex:50,animation:"fadeUp 0.3s ease"}}>
          ✏
        </button>
      )}

      {/* Header */}
      <div style={{background:`linear-gradient(160deg,${T.ink} 0%,#2d1f10 100%)`,padding:"48px 20px 20px"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
          <button onClick={onBack} style={{background:"rgba(255,255,255,0.08)",border:"none",borderRadius:20,padding:"6px 14px",color:"rgba(255,255,255,0.6)",fontSize:12,fontWeight:600,cursor:"pointer"}}>← Mood board</button>
          {status==="done"&&<button onClick={()=>setShowShare(true)} style={{background:T.accent,border:"none",borderRadius:20,padding:"6px 14px",color:T.white,fontSize:12,fontWeight:700,cursor:"pointer"}}>Share ↗</button>}
        </div>
        {status==="done" && (
          <div style={{background:"rgba(196,154,60,0.12)",borderRadius:12,padding:"10px 14px",marginTop:12,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
            {tripSaved
              ? <span style={{fontSize:12,color:T.gold,fontWeight:600}}>✦ Saved to your trips</span>
              : <button onClick={saveTrip} style={{background:"none",border:"none",color:T.gold,fontSize:12,fontWeight:700,cursor:"pointer",padding:0}}>♥ Save this trip</button>
            }
            <button onClick={()=>setShowShare(true)} style={{background:"none",border:"none",color:T.gold,fontSize:12,fontWeight:700,cursor:"pointer"}}>Share →</button>
          </div>
        )}
        <div style={{display:"none"}}>
        </div>
        <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.16em",textTransform:"uppercase",color:"rgba(196,154,60,0.7)",marginBottom:6}}>✦ YOUR ITINERARY</div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:26,fontWeight:700,color:T.white,marginBottom:4}}>{city}</div>
        {dates&&<div style={{fontSize:12,color:"rgba(255,255,255,0.4)"}}>{dates}</div>}
        {/* Day progress bars */}
        <div style={{display:"flex",gap:5,marginTop:14}}>
          {Array(totalDays).fill(null).map((_,i)=>(
            <div key={i} onClick={()=>i<daysData.length&&setActiveDay(i)}
              style={{flex:1,height:3,borderRadius:2,background:i<daysData.length?(i===activeDay?T.accent:"rgba(200,75,47,0.4)"):i===loadingDay-1?"rgba(200,75,47,0.2)":"rgba(255,255,255,0.1)",cursor:i<daysData.length?"pointer":"default",transition:"all 0.3s",animation:i===loadingDay-1&&daysData.length<=i?"pulse 1s ease infinite":undefined}}/>
          ))}
        </div>
        {stillLoading&&<div style={{fontSize:11,color:"rgba(255,255,255,0.3)",marginTop:8}}>{statusMsg}</div>}
      </div>

      {/* Day selector tabs */}
      <div style={{display:"flex",gap:8,padding:"14px 16px 0",overflowX:"auto"}}>
        {Array(totalDays).fill(null).map((_,i)=>{
          const ready=i<daysData.length, active=activeDay===i;
          return (
            <button key={i} onClick={()=>ready&&setActiveDay(i)} disabled={!ready}
              style={{flexShrink:0,padding:"7px 14px",borderRadius:20,border:`2px solid ${active?T.ink:ready?T.dust:"transparent"}`,background:active?T.ink:ready?T.white:T.paper,color:active?T.white:ready?T.inkLight:T.dust,fontSize:12,fontWeight:700,cursor:ready?"pointer":"default",display:"flex",alignItems:"center",gap:5}}>
              Day {i+1}
              {!ready&&<span style={{fontSize:10,animation:"pulse 1s ease infinite",opacity:0.5}}>…</span>}
            </button>
          );
        })}
      </div>

      {/* Stories-style swipeable moment cards */}
      <MomentCards
        day={day}
        activeDay={activeDay}
        ratings={ratings}
        activeSlot={activeSlot}
        checkIn={checkIn}
        checkOut={checkOut}
        setSelectedPlace={setSelectedPlace}
        BUCKET_COLORS={BUCKET_COLORS}
        getBucket={getBucket}
        TRANSIT_ICONS={TRANSIT_ICONS}
        TRANSIT_COLORS={TRANSIT_COLORS}
        onUpdateSlots={(newSlots) => {
          setDaysData(prev => prev.map((d, i) =>
            i === activeDay ? { ...d, slots: newSlots } : d
          ));
        }}
      />

      {/* Day nav */}
      <div style={{position:"fixed",bottom:NAV_H+8,left:"50%",transform:"translateX(-50%)",display:"flex",gap:10,zIndex:50}}>
        {activeDay>0&&<button onClick={()=>setActiveDay(d=>d-1)} style={{padding:"12px 20px",borderRadius:28,background:T.white,border:`1px solid ${T.dust}`,color:T.ink,fontSize:13,fontWeight:700,cursor:"pointer",boxShadow:"0 4px 16px rgba(28,22,18,0.08)"}}>← Day {activeDay}</button>}
        {activeDay<daysData.length-1&&<button onClick={()=>setActiveDay(d=>d+1)} style={{padding:"12px 20px",borderRadius:28,background:T.ink,border:"none",color:T.white,fontSize:13,fontWeight:700,cursor:"pointer",boxShadow:"0 4px 16px rgba(28,22,18,0.2)"}}>Day {activeDay+2} →</button>}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// PLACE DETAIL SHEET — Beli-inspired
// ─────────────────────────────────────────────
export { ItineraryView };