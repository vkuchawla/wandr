import { useState } from "react";
import { T } from "./constants.jsx";
function ShareCard({ city, dates, days, onClose }) {
  const [copied, setCopied] = useState(false);

  const text = `✦ WANDR — ${city}\n${dates||""}\n\n` +
    (days||[]).map(d=>`Day ${d.day}: ${d.theme}\n${(d.slots||[]).map(s=>`  ${s.time} — ${s.name} (${s.neighborhood})`).join("\n")}`).join("\n\n") +
    "\n\nPlanned with Wandr ✦";

  const copy = () => {
    navigator.clipboard?.writeText(text).then(()=>{setCopied(true);setTimeout(()=>setCopied(false),2200);}).catch(()=>{});
  };

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(28,22,18,0.7)",zIndex:200,display:"flex",alignItems:"flex-end",justifyContent:"center",animation:"fadeIn 0.2s ease"}} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{background:T.white,borderRadius:"24px 24px 0 0",padding:"24px 20px 40px",width:"100%",maxWidth:480,animation:"slideUp 0.3s ease",fontFamily:"'DM Sans',sans-serif"}}>
        <div style={{width:36,height:4,borderRadius:2,background:T.dust,margin:"0 auto 20px"}}/>
        {/* Card preview */}
        <div style={{background:`linear-gradient(135deg,${T.ink},#2d1f10)`,borderRadius:18,padding:"22px 20px",marginBottom:18,position:"relative",overflow:"hidden"}}>
          <div style={{position:"absolute",top:-10,right:-10,fontSize:60,opacity:0.07}}>✦</div>
          <div style={{fontSize:10,fontWeight:700,letterSpacing:"0.2em",color:"rgba(196,154,60,0.7)",marginBottom:8}}>✦ WANDR</div>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:24,fontWeight:700,color:T.white,marginBottom:4}}>{city}</div>
          {dates&&<div style={{fontSize:12,color:"rgba(255,255,255,0.4)",marginBottom:16}}>{dates}</div>}
          {(days||[]).slice(0,3).map(d=>(
            <div key={d.day} style={{marginBottom:8}}>
              <div style={{fontSize:11,fontWeight:700,color:T.gold,marginBottom:2}}>Day {d.day}</div>
              <div style={{fontSize:13,fontStyle:"italic",color:"rgba(255,255,255,0.7)",fontFamily:"'Playfair Display',serif"}}>{d.theme}</div>
            </div>
          ))}
        </div>
        <div style={{display:"flex",gap:10}}>
          <button onClick={copy} style={{flex:1,padding:14,borderRadius:14,background:copied?T.sage:T.ink,border:"none",color:T.white,fontSize:14,fontWeight:700,cursor:"pointer",transition:"background 0.2s"}}>
            {copied?"✓ Copied!":"Copy trip"}
          </button>
          <button onClick={onClose} style={{padding:"14px 18px",borderRadius:14,background:T.paper,border:"none",color:T.inkLight,fontSize:14,fontWeight:700,cursor:"pointer"}}>Done</button>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// SAVED TRIPS
// ─────────────────────────────────────────────
// ─────────────────────────────────────────────
// CITY PAGE — friend trips + social signal
// ─────────────────────────────────────────────
export { ShareCard };