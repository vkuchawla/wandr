import { useState, useEffect, useRef } from "react";
import { T, GLOBAL_CSS, NAV_H } from "./constants.jsx";
function HomeScreen({ onStart, savedTrips, profile, onOpenTrip }) {
  const [city, setCity]     = useState("");
  const [startDate, setStart] = useState(null);
  const [endDate, setEnd]     = useState(null);
  const [picking, setPicking] = useState(null);
  const [calOffset, setCalOffset] = useState(0);
  const [hoverDay, setHoverDay]   = useState(null);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const autocompleteTimer = useRef(null);
  const BACKEND = "http://192.168.12.108:3001";

  const handleCityChange = (val) => {
    setCity(val);
    clearTimeout(autocompleteTimer.current);
    if (val.length < 2) { setSuggestions([]); setShowSuggestions(false); return; }
    autocompleteTimer.current = setTimeout(async () => {
      try {
        const res = await fetch(`${BACKEND}/autocomplete?q=${encodeURIComponent(val)}`);
        const data = await res.json();
        setSuggestions(data.suggestions || []);
        setShowSuggestions(true);
      } catch(e) { setSuggestions([]); }
    }, 300);
  };

  const selectSuggestion = (s) => {
    setCity(s.description ? `${s.name}, ${s.description}` : s.name);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const today = new Date(); today.setHours(0,0,0,0);
  const fmt   = d => d ? `${MONTHS_SHORT[d.getMonth()]} ${d.getDate()}` : null;
  const dateString = startDate && endDate
    ? `${fmt(startDate)} – ${fmt(endDate)}, ${endDate.getFullYear()}`
    : startDate ? `From ${fmt(startDate)}` : "";

  const buildCal = () => {
    const base = new Date(); base.setDate(1); base.setMonth(base.getMonth()+calOffset);
    return { year:base.getFullYear(), month:base.getMonth(), firstDay:new Date(base.getFullYear(),base.getMonth(),1).getDay(), daysInMonth:new Date(base.getFullYear(),base.getMonth()+1,0).getDate(), label:`${MONTHS_FULL[base.getMonth()]} ${base.getFullYear()}` };
  };
  const cal = buildCal();

  const handleDay = day => {
    const d = new Date(cal.year, cal.month, day);
    if (d < today) return;
    if (!startDate || picking==="start") { setStart(d); setEnd(null); setPicking("end"); }
    else if (picking==="end") { if(d<startDate){setStart(d);setEnd(null);}else{setEnd(d);setPicking(null);} }
  };
  const inRange = day => {
    const d = new Date(cal.year,cal.month,day);
    if (startDate && hoverDay && !endDate) return d>startDate && d<=hoverDay;
    if (startDate && endDate) return d>startDate && d<endDate;
    return false;
  };

  const CITY_PILLS = ["New York","Tokyo","Paris","London","Barcelona","New Orleans","Nashville","Miami","Lisbon","Mexico City","Kyoto","Seoul","Amsterdam","Buenos Aires","Cape Town","Marrakech"];
  const greeting = profile?.name ? `Welcome back, ${profile.name.split(" ")[0]}.` : "Where next?";

  return (
    <div style={{minHeight:"100vh",background:T.cream,fontFamily:"'DM Sans',sans-serif",paddingBottom:NAV_H}}>
      <style>{GLOBAL_CSS}</style>

      {/* Hero header */}
      <div style={{padding:"56px 24px 28px",background:`linear-gradient(175deg, #1c1612 0%, #2d1f10 60%, ${T.cream} 100%)`,position:"relative",overflow:"hidden"}}>
        {/* Texture overlay */}
        <div style={{position:"absolute",inset:0,backgroundImage:"radial-gradient(circle at 20% 50%, rgba(196,154,60,0.08) 0%, transparent 60%), radial-gradient(circle at 80% 20%, rgba(200,75,47,0.06) 0%, transparent 50%)",pointerEvents:"none"}}/>
        <div style={{position:"relative",zIndex:1}}>
          <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.22em",textTransform:"uppercase",color:"rgba(196,154,60,0.7)",marginBottom:12}}>✦ WANDR</div>
          <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:38,fontWeight:900,color:T.white,lineHeight:1.08,marginBottom:8,animation:"fadeUp 0.5s ease both"}}>
            {greeting}
          </h1>
          <p style={{fontSize:14,color:"rgba(255,255,255,0.4)",fontWeight:300,lineHeight:1.7,animation:"fadeUp 0.5s ease 0.1s both"}}>Set your vibe. AI builds the rest.</p>
        </div>
      </div>

      {/* Search card */}
      <div style={{margin:"-1px 18px 0",background:T.white,borderRadius:"20px 20px 0 0",padding:"22px 20px 20px",boxShadow:"0 -4px 24px rgba(28,22,18,0.08)",position:"relative",zIndex:2}}>
        <div style={{position:"relative",marginBottom:10}}>
          <input value={city} onChange={e=>handleCityChange(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&city.trim()&&onStart(city.trim(),dateString)}
            onBlur={()=>setTimeout(()=>setShowSuggestions(false),150)}
            onFocus={()=>suggestions.length>0&&setShowSuggestions(true)}
            placeholder="City or destination…"
            style={{width:"100%",padding:"14px 16px",borderRadius:14,border:`1.5px solid ${city?T.accent:T.dust}`,background:T.cream,color:T.ink,fontSize:16,fontWeight:600,outline:"none",transition:"border-color 0.2s"}}/>
          {/* Autocomplete dropdown */}
          {showSuggestions && suggestions.length > 0 && (
            <div style={{position:"absolute",top:"calc(100% + 6px)",left:0,right:0,background:T.white,borderRadius:14,boxShadow:"0 8px 24px rgba(28,22,18,0.12)",border:`1px solid ${T.dust}`,zIndex:50,overflow:"hidden"}}>
              {suggestions.map((s,i)=>(
                <button key={i} onMouseDown={()=>selectSuggestion(s)}
                  style={{width:"100%",padding:"12px 16px",background:"none",border:"none",cursor:"pointer",textAlign:"left",display:"flex",alignItems:"center",gap:10,borderBottom:i<suggestions.length-1?`1px solid ${T.dust}`:"none",transition:"background 0.1s"}}
                  onMouseEnter={e=>e.currentTarget.style.background=T.paper}
                  onMouseLeave={e=>e.currentTarget.style.background="none"}>
                  <span style={{fontSize:16}}>📍</span>
                  <div>
                    <div style={{fontSize:14,fontWeight:700,color:T.ink}}>{s.name}</div>
                    {s.description && <div style={{fontSize:12,color:T.inkFaint}}>{s.description}</div>}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Date row */}
        <div style={{display:"flex",gap:8,marginBottom:picking?12:0}}>
          {[["start","Depart",startDate],["end","Return",endDate]].map(([key,lbl,val])=>(
            <button key={key} onClick={()=>setPicking(key)}
              style={{flex:1,padding:"11px 14px",borderRadius:12,border:`1.5px solid ${picking===key?T.accent:T.dust}`,background:picking===key?"#fdf8f4":T.cream,cursor:"pointer",textAlign:"left",transition:"all 0.15s"}}>
              <div style={{fontSize:9,fontWeight:700,letterSpacing:"0.12em",textTransform:"uppercase",color:T.inkFaint,marginBottom:2}}>{lbl}</div>
              <div style={{fontSize:13,fontWeight:700,color:val?T.ink:T.inkFaint}}>{val?fmt(val):"Select date"}</div>
            </button>
          ))}
          {(startDate||endDate)&&(
            <button onClick={()=>{setStart(null);setEnd(null);setPicking(null);}} style={{padding:"0 12px",borderRadius:12,border:`1.5px solid ${T.dust}`,background:"none",color:T.inkFaint,cursor:"pointer",fontSize:16}}>✕</button>
          )}
        </div>

        {/* Calendar */}
        {picking && (
          <div style={{background:T.cream,borderRadius:14,padding:14,marginBottom:12,animation:"fadeIn 0.2s ease"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
              <button onClick={()=>setCalOffset(o=>o-1)} style={{background:"none",border:"none",cursor:"pointer",color:T.inkLight,fontSize:20,padding:"0 6px"}}>‹</button>
              <span style={{fontSize:13,fontWeight:700,color:T.ink}}>{cal.label}</span>
              <button onClick={()=>setCalOffset(o=>o+1)} style={{background:"none",border:"none",cursor:"pointer",color:T.inkLight,fontSize:20,padding:"0 6px"}}>›</button>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2,textAlign:"center"}}>
              {["S","M","T","W","T","F","S"].map((d,i)=><div key={i} style={{fontSize:10,color:T.inkFaint,padding:"3px 0",fontWeight:700}}>{d}</div>)}
              {Array(cal.firstDay).fill(null).map((_,i)=><div key={`e${i}`}/>)}
              {Array(cal.daysInMonth).fill(null).map((_,i)=>{
                const day=i+1; const d=new Date(cal.year,cal.month,day);
                const isPast=d<today;
                const isStart=startDate&&d.toDateString()===startDate.toDateString();
                const isEnd=endDate&&d.toDateString()===endDate.toDateString();
                const isIn=inRange(day);
                return (
                  <button key={day} onClick={()=>handleDay(day)}
                    onMouseEnter={()=>{if(picking==="end"&&startDate)setHoverDay(new Date(cal.year,cal.month,day));}}
                    onMouseLeave={()=>setHoverDay(null)}
                    disabled={isPast}
                    style={{padding:"7px 2px",borderRadius:8,border:"none",background:isStart||isEnd?T.accent:isIn?"rgba(200,75,47,0.12)":"transparent",color:isPast?T.dust:isStart||isEnd?T.white:T.ink,fontSize:12,cursor:isPast?"default":"pointer",fontWeight:isStart||isEnd?700:400,transition:"all 0.1s"}}>
                    {day}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* City suggestions */}
        <div style={{display:"flex",flexWrap:"wrap",gap:7,marginBottom:16,marginTop:4}}>
          {CITY_PILLS.map(s=>(
            <button key={s} onClick={()=>setCity(s)}
              style={{padding:"6px 13px",borderRadius:20,border:`1.5px solid ${city===s?T.accent:T.dust}`,background:city===s?T.accent:"transparent",color:city===s?T.white:T.inkLight,fontSize:12,fontWeight:600,cursor:"pointer",transition:"all 0.15s"}}>
              {s}
            </button>
          ))}
        </div>

        <button onClick={()=>city.trim()&&onStart(city.trim(),dateString)} disabled={!city.trim()}
          style={{width:"100%",padding:16,borderRadius:16,background:city.trim()?`linear-gradient(135deg,${T.accent},#9b2020)`:T.dust,border:"none",color:city.trim()?T.white:T.inkFaint,fontSize:15,fontWeight:800,cursor:city.trim()?"pointer":"default",boxShadow:city.trim()?"0 6px 24px rgba(200,75,47,0.3)":"none",transition:"all 0.2s",letterSpacing:"0.02em"}}>
          Set the mood ✦
        </button>
      </div>

      {/* Recent trips */}
      {savedTrips.length > 0 && (
        <div style={{padding:"22px 20px 0"}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
            <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.14em",textTransform:"uppercase",color:T.inkFaint}}>Recent trips</div>
            {savedTrips.length > 3 && <button onClick={()=>onOpenTrip(null)} style={{background:"none",border:"none",fontSize:12,color:T.accent,fontWeight:700,cursor:"pointer",padding:0}}>See all →</button>}
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            {savedTrips.slice(0,3).map((trip,i)=>(
              <div key={i} onClick={()=>onOpenTrip(trip)}
                style={{background:T.white,borderRadius:16,padding:"14px 16px",display:"flex",alignItems:"center",gap:13,cursor:"pointer",border:`1px solid ${T.dust}`,boxShadow:"0 2px 8px rgba(28,22,18,0.04)"}}>
                <div style={{width:42,height:42,borderRadius:12,background:`linear-gradient(135deg,${T.ink},${T.inkLight})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>
                  {trip.emoji||"✦"}
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:15,fontWeight:700,color:T.ink}}>{trip.city}</div>
                  <div style={{fontSize:12,color:T.inkFaint}}>{trip.dates||"No dates set"}</div>
                </div>
                <div style={{fontSize:18,color:T.dust}}>›</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// PROFILE / TRAVEL STYLE QUIZ
// ─────────────────────────────────────────────
export { HomeScreen };