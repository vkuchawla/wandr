import { useState } from "react";
import { T, GLOBAL_CSS, NAV_H, EXPLORE_CITIES } from "./constants.jsx";
function ExploreScreen({ onSelectCity }) {
  const [activeVibe, setActiveVibe] = useState(null);

  // Split cities into two rows for marquee effect
  const row1 = [...EXPLORE_CITIES.slice(0, 8), ...EXPLORE_CITIES.slice(0, 8)];
  const row2 = [...EXPLORE_CITIES.slice(8), ...EXPLORE_CITIES.slice(0, 8), ...EXPLORE_CITIES.slice(8), ...EXPLORE_CITIES.slice(0, 8)];

  const CityCard = ({ c }) => (
    <div onClick={()=>onSelectCity(c.city)}
      style={{flexShrink:0,width:180,height:110,borderRadius:18,overflow:"hidden",cursor:"pointer",background:c.bg,display:"flex",alignItems:"flex-end",padding:"14px",position:"relative",boxShadow:"0 4px 16px rgba(28,22,18,0.2)",marginRight:12}}>
      <div style={{position:"absolute",top:10,right:12,fontSize:28,opacity:0.25}}>{c.emoji}</div>
      <div style={{position:"absolute",inset:0,background:"linear-gradient(to bottom,transparent 30%,rgba(0,0,0,0.5) 100%)"}}/>
      <div style={{position:"relative",zIndex:1}}>
        <div style={{fontSize:9,fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:c.accent,marginBottom:2}}>{c.tag}</div>
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:16,fontWeight:700,color:T.white,lineHeight:1.2}}>{c.city}</div>
      </div>
    </div>
  );

  return (
    <div style={{minHeight:"100vh",background:T.cream,fontFamily:"'DM Sans',sans-serif",paddingBottom:NAV_H,overflow:"hidden"}}>
      <style>{GLOBAL_CSS}</style>
      <div style={{padding:"56px 20px 20px"}}>
        <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.22em",textTransform:"uppercase",color:T.gold,marginBottom:12}}>✦ EXPLORE</div>
        <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:32,fontWeight:700,color:T.ink,lineHeight:1.2,marginBottom:4}}>Get inspired.</h1>
        <p style={{fontSize:14,color:T.inkFaint,lineHeight:1.6}}>Tap a city to start planning.</p>
      </div>

      {/* Marquee row 1 — scrolls left */}
      <div style={{overflow:"hidden",marginBottom:12,padding:"4px 0"}}>
        <div style={{display:"flex",animation:"marquee1 30s linear infinite",width:"max-content"}}>
          {row1.map((c,i)=><CityCard key={i} c={c}/>)}
        </div>
      </div>

      {/* Marquee row 2 — scrolls right */}
      <div style={{overflow:"hidden",marginBottom:24,padding:"4px 0"}}>
        <div style={{display:"flex",animation:"marquee2 35s linear infinite",width:"max-content"}}>
          {row2.map((c,i)=><CityCard key={i} c={c}/>)}
        </div>
      </div>

      {/* Vibe filter pills */}
      <div style={{padding:"0 20px 16px"}}>
        <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.14em",textTransform:"uppercase",color:T.inkFaint,marginBottom:12}}>Filter by vibe</div>
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          <button onClick={()=>setActiveVibe(null)}
            style={{padding:"7px 16px",borderRadius:20,border:`1.5px solid ${!activeVibe?T.ink:T.dust}`,background:!activeVibe?T.ink:"transparent",color:!activeVibe?T.white:T.inkLight,fontSize:12,fontWeight:700,cursor:"pointer"}}>
            All
          </button>
          {VIBES.slice(0,8).map(v=>(
            <button key={v.id} onClick={()=>setActiveVibe(activeVibe===v.id?null:v.id)}
              style={{padding:"7px 14px",borderRadius:20,border:`1.5px solid ${activeVibe===v.id?v.color:T.dust}`,background:activeVibe===v.id?v.bg:"transparent",color:activeVibe===v.id?v.color:T.inkLight,fontSize:12,fontWeight:700,cursor:"pointer",display:"flex",alignItems:"center",gap:5}}>
              {v.emoji} {v.label}
            </button>
          ))}
        </div>
      </div>

      {/* All cities grid */}
      <div style={{padding:"0 20px",display:"flex",flexDirection:"column",gap:10}}>
        <div style={{fontSize:11,fontWeight:700,letterSpacing:"0.14em",textTransform:"uppercase",color:T.inkFaint,marginBottom:4}}>All destinations</div>
        {EXPLORE_CITIES.map((c,i)=>(
          <div key={c.city} onClick={()=>onSelectCity(c.city)}
            style={{borderRadius:18,overflow:"hidden",cursor:"pointer",background:c.bg,height:70,display:"flex",alignItems:"center",padding:"0 20px",position:"relative",boxShadow:"0 2px 12px rgba(28,22,18,0.12)"}}>
            <div style={{position:"absolute",right:16,fontSize:28,opacity:0.2}}>{c.emoji}</div>
            <div style={{flex:1}}>
              <div style={{fontSize:10,fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:c.accent,marginBottom:2}}>{c.tag}</div>
              <div style={{fontFamily:"'Playfair Display',serif",fontSize:18,fontWeight:700,color:T.white}}>{c.city}</div>
            </div>
            <div style={{color:"rgba(255,255,255,0.4)",fontSize:18}}>›</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// MOOD BOARD
// ─────────────────────────────────────────────
export { ExploreScreen };